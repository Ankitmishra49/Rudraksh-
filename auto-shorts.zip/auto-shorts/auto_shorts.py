"""
Auto YouTube Shorts (100% free stack)
Gemini (script) -> edge-tts (Hindi voice) -> Pexels (clips) -> MoviePy (edit) -> YouTube API (upload)

Setup:
  1. pip install -r requirements.txt
  2. Keys (all free):
       GEMINI_API_KEY  -> aistudio.google.com/apikey
       PEXELS_API_KEY  -> pexels.com/api
       YouTube OAuth   -> Google Cloud Console: enable "YouTube Data API v3",
                          create OAuth client (Desktop app), download as client_secret.json
  3. First run on your PC:  python auto_shorts.py
     (browser opens, log in once; token.json is created)
  4. For daily auto-run: put token.json contents in GitHub secret YT_TOKEN_JSON
     and use daily.yml
"""
import os, json, re, asyncio, random, datetime, requests
import edge_tts
import PIL.Image
if not hasattr(PIL.Image, "ANTIALIAS"):  # moviepy 1.0.3 + Pillow>=10 fix
    PIL.Image.ANTIALIAS = PIL.Image.LANCZOS
from moviepy.editor import VideoFileClip, AudioFileClip, concatenate_videoclips
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

GEMINI_KEY = os.environ["GEMINI_API_KEY"]
PEXELS_KEY = os.environ["PEXELS_API_KEY"]
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
NICHE = os.getenv("NICHE", "रोचक तथ्य (amazing facts)")
VOICE = os.getenv("VOICE", "hi-IN-MadhurNeural")  # female: hi-IN-SwaraNeural
PRIVACY = os.getenv("PRIVACY", "public")  # public / unlisted / private
SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]


def make_script():
    prompt = f"""तुम एक YouTube Shorts राइटर हो। niche: {NICHE}।
आज की तारीख {datetime.date.today()} है। एक बिल्कुल नया, अनोखा टॉपिक चुनो (seed {random.randint(1, 99999)}).
सिर्फ JSON दो, और कुछ नहीं:
{{"title": "आकर्षक हिंदी टाइटल (80 अक्षर तक)",
 "script": "हिंदी वॉइसओवर, 90-110 शब्द, पहली लाइन में ज़बरदस्त हुक, आखिर में फॉलो करने को कहो",
 "keywords": ["3 english words for stock video search"],
 "description": "2 लाइन डिस्क्रिप्शन",
 "tags": ["5 tags"]}}"""
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent?key={GEMINI_KEY}"
    r = requests.post(url, json={"contents": [{"parts": [{"text": prompt}]}]}, timeout=60)
    r.raise_for_status()
    text = r.json()["candidates"][0]["content"]["parts"][0]["text"]
    text = re.sub(r"```json|```", "", text).strip()
    return json.loads(text)


async def make_voice(text, path="voice.mp3"):
    await edge_tts.Communicate(text, VOICE).save(path)
    return path


def download_clips(keywords, n=4):
    files = []
    for i, kw in enumerate(keywords * 2):
        if len(files) >= n:
            break
        r = requests.get(
            "https://api.pexels.com/videos/search",
            headers={"Authorization": PEXELS_KEY},
            params={"query": kw, "orientation": "portrait", "per_page": 8},
            timeout=30,
        )
        vids = r.json().get("videos", [])
        random.shuffle(vids)
        for v in vids:
            best = [f for f in v["video_files"] if f["height"] >= 1280 and f["width"] < f["height"]]
            if not best:
                continue
            link = min(best, key=lambda f: f["height"])["link"]
            p = f"clip{len(files)}.mp4"
            with open(p, "wb") as fh:
                fh.write(requests.get(link, timeout=120).content)
            files.append(p)
            break
    if not files:
        raise RuntimeError("Pexels से कोई क्लिप नहीं मिली")
    return files


def fit(c):
    c = c.resize(height=1920)
    if c.w < 1080:
        c = c.resize(width=1080)
    return c.crop(x_center=c.w / 2, y_center=c.h / 2, width=1080, height=1920)


def build_video(clip_files, voice_path, out="short.mp4"):
    audio = AudioFileClip(voice_path)
    dur = min(audio.duration + 0.5, 59)
    clips, total = [], 0
    while total < dur:
        for f in clip_files:
            c = fit(VideoFileClip(f).without_audio())
            clips.append(c)
            total += c.duration
            if total >= dur:
                break
    video = concatenate_videoclips(clips).subclip(0, dur).set_audio(audio)
    video.write_videofile(out, fps=30, codec="libx264", audio_codec="aac", logger=None)
    return out


def yt_credentials():
    creds = None
    if os.getenv("YT_TOKEN_JSON"):
        creds = Credentials.from_authorized_user_info(json.loads(os.environ["YT_TOKEN_JSON"]), SCOPES)
    elif os.path.exists("token.json"):
        creds = Credentials.from_authorized_user_file("token.json", SCOPES)
    if creds and creds.expired and creds.refresh_token:
        creds.refresh(Request())
    if not creds or not creds.valid:
        flow = InstalledAppFlow.from_client_secrets_file("client_secret.json", SCOPES)
        creds = flow.run_local_server(port=0)
    if not os.getenv("YT_TOKEN_JSON"):
        with open("token.json", "w") as fh:
            fh.write(creds.to_json())
    return creds


def upload(path, meta):
    yt = build("youtube", "v3", credentials=yt_credentials())
    title = (meta["title"][:88] + " #Shorts")[:100]
    body = {
        "snippet": {
            "title": title,
            "description": meta["description"] + "\n\n#Shorts",
            "tags": meta.get("tags", []),
            "categoryId": "27",
        },
        "status": {"privacyStatus": PRIVACY, "selfDeclaredMadeForKids": False},
    }
    req = yt.videos().insert(part="snippet,status", body=body,
                             media_body=MediaFileUpload(path, resumable=True))
    resp = None
    while resp is None:
        _, resp = req.next_chunk()
    print("Uploaded: https://youtube.com/shorts/" + resp["id"])


if __name__ == "__main__":
    meta = make_script()
    print("Title:", meta["title"])
    voice = asyncio.run(make_voice(meta["script"]))
    clips = download_clips(meta["keywords"])
    video = build_video(clips, voice)
    upload(video, meta)
