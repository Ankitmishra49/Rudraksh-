AUTO YOUTUBE SHORTS (free)

1) pip install -r requirements.txt   (ffmpeg भी इंस्टॉल होना चाहिए)
2) Keys बनाएँ: GEMINI_API_KEY (aistudio.google.com/apikey), PEXELS_API_KEY (pexels.com/api)
3) Google Cloud में YouTube Data API v3 चालू करें, OAuth "Desktop app" client बनाएँ,
   client_secret.json इसी फोल्डर में रखें
4) Windows:  set GEMINI_API_KEY=...  &  set PEXELS_API_KEY=...  फिर  python auto_shorts.py
   Mac/Linux: export GEMINI_API_KEY=... ; export PEXELS_API_KEY=... ; python auto_shorts.py
   (पहली बार ब्राउज़र में लॉगिन -> token.json बनेगा)
5) रोज़ ऑटो: GitHub private repo में सब फाइलें डालें, Secrets में
   GEMINI_API_KEY, PEXELS_API_KEY, YT_TOKEN_JSON (token.json की पूरी सामग्री) जोड़ें।
   workflow फाइल .github/workflows/daily.yml में पहले से रखी है।

Optional env: NICHE, VOICE (hi-IN-SwaraNeural = महिला आवाज़), PRIVACY (public/unlisted/private)
नोट: client_secret.json और token.json किसी को शेयर न करें, GitHub पर public repo में न डालें।
