# Maus Backend (शुरुआती वर्ज़न)

## चलाने के चरण
1. PostgreSQL बनाइए (Neon / Supabase / AWS RDS) और `schema.sql` चलाइए।
2. Cloudflare R2 (या S3) बकेट बनाइए, CDN जोड़िए।
3. ये environment variables सेट कीजिए:
   DATABASE_URL, JWT_SECRET, S3_ENDPOINT, S3_BUCKET, S3_KEY, S3_SECRET, CDN_URL,
   ADMIN_TOKEN, AUTO_LIVE=1, REQUIRE_REVIEW=1, SCAN_REQUIRED=1, SCAN_URL, SCAN_TOKEN, SERVER_URL  (बच्चों की सुरक्षा के लिए SAFETY.md ज़रूर पढ़ें)
4. `npm install && npm start`

## अभी बाकी (production से पहले)
- SMS OTP भेजना (DLT-रजिस्टर्ड प्रोवाइडर, जैसे MSG91)
- वीडियो प्रोसेसिंग वर्कर (FFmpeg -> HLS) जो /internal/videos/:id/live को कॉल करे
- मॉडरेशन पैनल (reports टेबल) और शिकायत अधिकारी का संपर्क
- लॉगिंग, बैकअप, लोड टेस्ट
