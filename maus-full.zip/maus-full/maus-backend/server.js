// Maus backend starter: OTP login, presigned upload, feed, like, follow, report.
const express = require("express");
const rateLimit = require("express-rate-limit");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const { Pool } = require("pg");
const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");
const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");

const {
  DATABASE_URL, JWT_SECRET, S3_ENDPOINT, S3_BUCKET, S3_KEY, S3_SECRET, CDN_URL,
  PORT = 3000,
} = process.env;
if (!DATABASE_URL || !JWT_SECRET) throw new Error("DATABASE_URL and JWT_SECRET are required");

const pool = new Pool({ connectionString: DATABASE_URL });
const s3 = new S3Client({
  region: "auto", endpoint: S3_ENDPOINT,
  credentials: { accessKeyId: S3_KEY, secretAccessKey: S3_SECRET },
});
const app = express();
app.use(express.json({ limit: "50kb" }));
app.use(rateLimit({ windowMs: 60_000, max: 120 }));
const authLimiter = rateLimit({ windowMs: 10 * 60_000, max: 5 });

const hash = (s) => crypto.createHash("sha256").update(s).digest("hex");
const wrap = (fn) => (req, res) => fn(req, res).catch((e) => { console.error(e); res.status(500).json({ error: "server_error" }); });

function auth(req, res, next) {
  const t = (req.headers.authorization || "").replace("Bearer ", "");
  try { req.uid = jwt.verify(t, JWT_SECRET).uid; next(); }
  catch { res.status(401).json({ error: "login_required" }); }
}


// Blocks banned users and anyone who has not confirmed they are 18+.
async function adult(req, res, next) {
  try {
    const { rows } = await pool.query("SELECT age_verified, is_banned FROM users WHERE id=$1", [req.uid]);
    const u = rows[0];
    if (!u || u.is_banned) return res.status(403).json({ error: "blocked" });
    if (!u.age_verified) return res.status(403).json({ error: "age_required" });
    next();
  } catch (e) { console.error(e); res.status(500).json({ error: "server_error" }); }
}
function admin(req, res, next) {
  const a = Buffer.from(String(req.headers["x-admin-token"] || ""));
  const b = Buffer.from(String(process.env.ADMIN_TOKEN || ""));
  if (!b.length || a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.sendStatus(403);
  next();
}
const logMod = (action, videoId, userId, note = "") =>
  pool.query("INSERT INTO moderation_log(action, video_id, user_id, note) VALUES($1,$2,$3,$4)", [action, videoId || null, userId || null, note]);

// 1) OTP login ---------------------------------------------------------
app.post("/auth/send-otp", authLimiter, wrap(async (req, res) => {
  const phone = String(req.body.phone || "");
  if (!/^\+91[6-9]\d{9}$/.test(phone)) return res.status(400).json({ error: "bad_phone" });
  const code = String(crypto.randomInt(100000, 999999));
  await pool.query(
    `INSERT INTO otps(phone, code_hash, expires_at, tries) VALUES($1,$2, now()+interval '5 minutes', 0)
     ON CONFLICT (phone) DO UPDATE SET code_hash=$2, expires_at=now()+interval '5 minutes', tries=0`,
    [phone, hash(code)]);
  // TODO: send `code` by SMS using an Indian DLT-registered provider (MSG91, Twilio, etc.)
  console.log("OTP for", phone, code); // remove in production
  res.json({ ok: true });
}));

app.post("/auth/verify-otp", authLimiter, wrap(async (req, res) => {
  const { phone, code } = req.body;
  const { rows } = await pool.query("SELECT * FROM otps WHERE phone=$1", [phone]);
  const o = rows[0];
  if (!o || o.expires_at < new Date() || o.tries >= 5) return res.status(400).json({ error: "otp_invalid" });
  await pool.query("UPDATE otps SET tries=tries+1 WHERE phone=$1", [phone]);
  if (hash(String(code)) !== o.code_hash) return res.status(400).json({ error: "otp_invalid" });
  await pool.query("DELETE FROM otps WHERE phone=$1", [phone]);
  const u = await pool.query(
    "INSERT INTO users(phone) VALUES($1) ON CONFLICT (phone) DO UPDATE SET phone=EXCLUDED.phone RETURNING id, is_banned", [phone]);
  if (u.rows[0].is_banned) return res.status(403).json({ error: "banned" });
  res.json({ token: jwt.sign({ uid: u.rows[0].id }, JWT_SECRET, { expiresIn: "60d" }) });
}));

// 1b) Age gate: Maus is 18+ only. Date of birth is checked once and NOT stored.
app.post("/me/age", auth, wrap(async (req, res) => {
  const d = new Date(String(req.body.dob || ""));
  if (isNaN(d) || d > new Date() || d.getFullYear() < 1900) return res.status(400).json({ error: "bad_dob" });
  const now = new Date();
  let age = now.getFullYear() - d.getFullYear();
  const m = now.getMonth() - d.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < d.getDate())) age--;
  if (age < 18) {
    await pool.query("UPDATE users SET is_banned=TRUE WHERE id=$1", [req.uid]);
    return res.status(403).json({ error: "under_18" });
  }
  await pool.query("UPDATE users SET age_verified=TRUE WHERE id=$1", [req.uid]);
  res.json({ ok: true });
}));

// 2) Upload: app asks for a signed URL, uploads straight to storage ----
app.post("/videos/upload-url", auth, adult, wrap(async (req, res) => {
  const { title = "", durationSec, sizeBytes } = req.body;
  if (!(durationSec > 0) || sizeBytes > 500 * 1024 * 1024) return res.status(400).json({ error: "bad_video" });
  const kind = durationSec <= 90 ? "short" : "long";
  const key = `raw/${req.uid}/${crypto.randomUUID()}.mp4`;
  const url = await getSignedUrl(s3, new PutObjectCommand({ Bucket: S3_BUCKET, Key: key, ContentType: "video/mp4" }), { expiresIn: 900 });
  const v = await pool.query(
    "INSERT INTO videos(user_id, video_key, title, kind, duration_sec) VALUES($1,$2,$3,$4,$5) RETURNING id",
    [req.uid, key, String(title).slice(0, 150), kind, Math.round(durationSec)]);
  res.json({ videoId: v.rows[0].id, uploadUrl: url, kind });
}));

// App calls this after the file is uploaded. Without a transcoder (AUTO_LIVE=1) the raw MP4 goes live directly.
app.post("/videos/:id/complete", auth, adult, wrap(async (req, res) => {
  // REQUIRE_REVIEW=1: every new video waits for a moderator before anyone can see it.
  // SCAN_REQUIRED=1: video stays invisible ("scanning") until scan-worker.js clears it. Fails closed.
  const next = process.env.SCAN_REQUIRED === "1" ? "scanning"
    : process.env.REQUIRE_REVIEW === "1" ? "review" : "live";
  if (process.env.AUTO_LIVE === "1") {
    await pool.query("UPDATE videos SET status=$3 WHERE id=$1 AND user_id=$2 AND status='processing'", [req.params.id, req.uid, next]);
  }
  res.json({ ok: true, live: process.env.AUTO_LIVE === "1" && next === "live" });
}));

// Scan result from scan-worker.js. A "match" removes the video, bans the uploader and
// flags it LEGAL_REPORT_REQUIRED (file is kept as evidence; see SAFETY.md).
app.post("/internal/videos/:id/scan-result", wrap(async (req, res) => {
  if (req.headers["x-worker-secret"] !== hash(JWT_SECRET)) return res.sendStatus(403);
  const v = (await pool.query("SELECT user_id FROM videos WHERE id=$1", [req.params.id])).rows[0];
  if (!v) return res.sendStatus(404);
  if (req.body.result === "match") {
    await pool.query("UPDATE videos SET status='removed' WHERE id=$1", [req.params.id]);
    await pool.query("UPDATE users SET is_banned=TRUE WHERE id=$1", [v.user_id]);
    await logMod("scan_match", req.params.id, v.user_id, "LEGAL_REPORT_REQUIRED");
  } else if (req.body.result === "clear") {
    const next = process.env.REQUIRE_REVIEW === "1" ? "review" : "live";
    await pool.query("UPDATE videos SET status=$2 WHERE id=$1 AND status='scanning'", [req.params.id, next]);
    await logMod("scan_clear", req.params.id, v.user_id);
  } else {
    return res.status(400).json({ error: "bad_result" });
  }
  res.json({ ok: true });
}));

// Called by your transcoding worker (FFmpeg/Mux) when HLS is ready.
app.post("/internal/videos/:id/live", wrap(async (req, res) => {
  if (req.headers["x-worker-secret"] !== hash(JWT_SECRET)) return res.sendStatus(403);
  await pool.query("UPDATE videos SET status='live', video_key=$2 WHERE id=$1", [req.params.id, req.body.hlsKey]);
  res.json({ ok: true });
}));

// 3) Feed ----------------------------------------------------------------
app.get("/feed", wrap(async (req, res) => {
  const kind = req.query.kind === "long" ? "long" : "short";
  const before = req.query.before ? new Date(req.query.before) : new Date();
  const { rows } = await pool.query(
    `SELECT v.id, v.title, v.kind, v.duration_sec, v.like_count, v.created_at, v.video_key, u.username
     FROM videos v JOIN users u ON u.id=v.user_id
     WHERE v.status='live' AND v.kind=$1 AND v.created_at < $2
     ORDER BY v.created_at DESC LIMIT 20`, [kind, before]);
  res.json(rows.map((r) => ({ ...r, url: `${CDN_URL}/${r.video_key}` })));
}));

// 4) Like / follow / report ---------------------------------------------
app.post("/videos/:id/like", auth, adult, wrap(async (req, res) => {
  const ins = await pool.query("INSERT INTO likes VALUES($1,$2) ON CONFLICT DO NOTHING", [req.uid, req.params.id]);
  if (ins.rowCount) await pool.query("UPDATE videos SET like_count=like_count+1 WHERE id=$1", [req.params.id]);
  res.json({ ok: true });
}));
app.delete("/videos/:id/like", auth, adult, wrap(async (req, res) => {
  const del = await pool.query("DELETE FROM likes WHERE user_id=$1 AND video_id=$2", [req.uid, req.params.id]);
  if (del.rowCount) await pool.query("UPDATE videos SET like_count=like_count-1 WHERE id=$1", [req.params.id]);
  res.json({ ok: true });
}));
app.post("/users/:id/follow", auth, adult, wrap(async (req, res) => {
  await pool.query("INSERT INTO follows VALUES($1,$2) ON CONFLICT DO NOTHING", [req.uid, req.params.id]);
  res.json({ ok: true });
}));
const REASONS = ["child_safety", "sexual", "violence", "hate", "spam", "other"];
app.post("/videos/:id/report", auth, adult, wrap(async (req, res) => {
  const code = REASONS.includes(req.body.reasonCode) ? req.body.reasonCode : "other";
  await pool.query("INSERT INTO reports(video_id, reporter_id, reason_code, reason) VALUES($1,$2,$3,$4)",
    [req.params.id, req.uid, code, String(req.body.reason || "").slice(0, 300)]);
  // Child-safety / sexual reports hide the video immediately; others after 3 different reporters.
  let hold = code === "child_safety" || code === "sexual";
  if (!hold) {
    const c = await pool.query("SELECT COUNT(DISTINCT reporter_id)::int AS n FROM reports WHERE video_id=$1 AND status='open'", [req.params.id]);
    hold = c.rows[0].n >= 3;
  }
  if (hold) {
    await pool.query("UPDATE videos SET status='hold' WHERE id=$1 AND status='live'", [req.params.id]);
    await logMod("auto_hold", req.params.id, null, code);
  }
  res.json({ ok: true });
}));

// 5) Moderation (send header x-admin-token: <ADMIN_TOKEN>) ---------------
app.get("/admin/queue", admin, wrap(async (req, res) => {
  const { rows } = await pool.query(
    `SELECT v.id, v.title, v.status, v.user_id, v.video_key, v.created_at,
       (SELECT json_agg(json_build_object('code', r.reason_code, 'text', r.reason))
          FROM reports r WHERE r.video_id=v.id AND r.status='open') AS reports
     FROM videos v WHERE v.status IN ('review','hold')
     ORDER BY EXISTS(SELECT 1 FROM reports r WHERE r.video_id=v.id AND r.status='open'
                     AND r.reason_code IN ('child_safety','sexual')) DESC, v.created_at
     LIMIT 100`);
  res.json(rows.map((r) => ({ ...r, url: `${CDN_URL}/${r.video_key}` })));
}));
// Everything that needs a police / POCSO report. Handle with a lawyer; do not copy or forward the files.
app.get("/admin/legal-holds", admin, wrap(async (req, res) => {
  const { rows } = await pool.query(
    "SELECT id, action, video_id, user_id, created_at FROM moderation_log WHERE note LIKE '%LEGAL_REPORT_REQUIRED%' ORDER BY created_at DESC LIMIT 200");
  res.json(rows);
}));
app.post("/admin/videos/:id/approve", admin, wrap(async (req, res) => {
  await pool.query("UPDATE videos SET status='live' WHERE id=$1", [req.params.id]);
  await pool.query("UPDATE reports SET status='dismissed' WHERE video_id=$1 AND status='open'", [req.params.id]);
  await logMod("approve", req.params.id, null, String(req.body.note || ""));
  res.json({ ok: true });
}));
// Remove hides the video but keeps the file: evidence may have to be handed to the police.
app.post("/admin/videos/:id/remove", admin, wrap(async (req, res) => {
  await pool.query("UPDATE videos SET status='removed' WHERE id=$1", [req.params.id]);
  await pool.query("UPDATE reports SET status='actioned' WHERE video_id=$1 AND status='open'", [req.params.id]);
  await logMod("remove", req.params.id, null, (req.body.legal ? "LEGAL_REPORT_REQUIRED " : "") + String(req.body.note || ""));
  res.json({ ok: true });
}));
app.post("/admin/users/:id/ban", admin, wrap(async (req, res) => {
  await pool.query("UPDATE users SET is_banned=TRUE WHERE id=$1", [req.params.id]);
  await pool.query("UPDATE videos SET status='removed' WHERE user_id=$1", [req.params.id]);
  await logMod("ban_user", null, req.params.id, String(req.body.note || ""));
  res.json({ ok: true });
}));

app.get("/health", (_, res) => res.send("ok"));
app.listen(PORT, () => console.log("Maus backend on", PORT));
