-- Maus database (PostgreSQL)
CREATE TABLE users (
  id BIGSERIAL PRIMARY KEY,
  phone TEXT UNIQUE NOT NULL,
  username TEXT UNIQUE,
  bio TEXT DEFAULT '',
  is_banned BOOLEAN DEFAULT FALSE,   -- also used to block under-18 sign-ups
  age_verified BOOLEAN DEFAULT FALSE, -- 18+ self-declared; date of birth is NOT stored
  created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE otps (
  phone TEXT PRIMARY KEY,
  code_hash TEXT NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  tries INT DEFAULT 0
);
CREATE TABLE videos (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT REFERENCES users(id) ON DELETE CASCADE,
  video_key TEXT NOT NULL,          -- object key in R2/S3
  title TEXT DEFAULT '',
  kind TEXT CHECK (kind IN ('short','long')) NOT NULL,
  duration_sec INT NOT NULL,
  status TEXT DEFAULT 'processing', -- processing | review | live | hold | removed
  like_count INT DEFAULT 0,
  view_count INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX videos_feed ON videos (kind, status, created_at DESC);
CREATE TABLE likes (
  user_id BIGINT REFERENCES users(id) ON DELETE CASCADE,
  video_id BIGINT REFERENCES videos(id) ON DELETE CASCADE,
  PRIMARY KEY (user_id, video_id)
);
CREATE TABLE follows (
  follower_id BIGINT REFERENCES users(id) ON DELETE CASCADE,
  followee_id BIGINT REFERENCES users(id) ON DELETE CASCADE,
  PRIMARY KEY (follower_id, followee_id)
);
CREATE TABLE reports (            -- IT Rules: report + takedown trail
  id BIGSERIAL PRIMARY KEY,
  video_id BIGINT REFERENCES videos(id) ON DELETE CASCADE,
  reporter_id BIGINT REFERENCES users(id),
  reason_code TEXT NOT NULL DEFAULT 'other', -- child_safety | sexual | violence | hate | spam | other
  reason TEXT NOT NULL DEFAULT '',
  status TEXT DEFAULT 'open',     -- open | actioned | dismissed
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE moderation_log (       -- audit trail of every takedown / approval
  id BIGSERIAL PRIMARY KEY,
  action TEXT NOT NULL,
  video_id BIGINT,
  user_id BIGINT,
  note TEXT DEFAULT '',
  created_at TIMESTAMPTZ DEFAULT now()
);
