// Scan worker: checks every new upload before it can go live.
// Run next to the server:  node scan-worker.js
// Needs: DATABASE_URL, JWT_SECRET, S3_*, SERVER_URL (your server's address),
//        SCAN_URL + SCAN_TOKEN (your scanning provider).
//
// Provider contract this file expects (adapt the fetch() below to your provider's real API):
//   POST SCAN_URL  {url, videoId}  ->  {"match": true|false}
// If the provider fails or is down, the video STAYS hidden and is retried. It never goes live unscanned.
const crypto = require("crypto");
const { Pool } = require("pg");
const { S3Client, GetObjectCommand } = require("@aws-sdk/client-s3");
const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");

const { DATABASE_URL, JWT_SECRET, S3_ENDPOINT, S3_BUCKET, S3_KEY, S3_SECRET, SERVER_URL, SCAN_URL, SCAN_TOKEN } = process.env;
if (!DATABASE_URL || !JWT_SECRET || !SERVER_URL || !SCAN_URL || !SCAN_TOKEN) throw new Error("Missing env for scan-worker");
const pool = new Pool({ connectionString: DATABASE_URL });
const s3 = new S3Client({ region: "auto", endpoint: S3_ENDPOINT, credentials: { accessKeyId: S3_KEY, secretAccessKey: S3_SECRET } });
const secret = crypto.createHash("sha256").update(JWT_SECRET).digest("hex");

async function scanOne(v) {
  const url = await getSignedUrl(s3, new GetObjectCommand({ Bucket: S3_BUCKET, Key: v.video_key }), { expiresIn: 600 });
  const r = await fetch(SCAN_URL, {
    method: "POST",
    headers: { Authorization: `Bearer ${SCAN_TOKEN}`, "Content-Type": "application/json" },
    body: JSON.stringify({ url, videoId: v.id }),
  });
  if (!r.ok) throw new Error("scanner " + r.status);
  const out = await r.json();
  const res = await fetch(`${SERVER_URL}/internal/videos/${v.id}/scan-result`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-worker-secret": secret },
    body: JSON.stringify({ result: out.match ? "match" : "clear" }),
  });
  if (!res.ok) throw new Error("server " + res.status);
}

async function loop() {
  try {
    const { rows } = await pool.query("SELECT id, video_key FROM videos WHERE status='scanning' ORDER BY created_at LIMIT 5");
    for (const v of rows) {
      try { await scanOne(v); console.log("scanned", v.id); }
      catch (e) { console.error("scan failed (will retry)", v.id, e.message); }
    }
  } catch (e) { console.error(e.message); }
  setTimeout(loop, 10_000);
}
loop();
