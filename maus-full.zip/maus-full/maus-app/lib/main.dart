import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

// ===== बस इतना बदलिए: अपने बैकएंड का पता =====
const apiBase = 'https://YOUR-SERVER.com';
// ==============================================

class Api {
  static String? token;
  static bool adult = false;
  static Map<String, String> get _h => {
        'Content-Type': 'application/json',
        if (token != null) 'Authorization': 'Bearer $token',
      };
  static Future<http.Response> post(String p, [Map? body]) =>
      http.post(Uri.parse('$apiBase$p'), headers: _h, body: jsonEncode(body ?? {}));
  static Future<http.Response> del(String p) =>
      http.delete(Uri.parse('$apiBase$p'), headers: _h);
  static Future<List<dynamic>> feed(String kind, [String? before]) async {
    final q = before == null ? '' : '&before=${Uri.encodeComponent(before)}';
    final r = await http.get(Uri.parse('$apiBase/feed?kind=$kind$q'));
    if (r.statusCode != 200) throw Exception('feed ${r.statusCode}');
    return jsonDecode(r.body) as List<dynamic>;
  }
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  Api.token = prefs.getString('token');
  Api.adult = prefs.getBool('adult') ?? false;
  runApp(const MausApp());
}

class MausApp extends StatefulWidget {
  const MausApp({super.key});
  @override
  State<MausApp> createState() => _MausAppState();
}

class _MausAppState extends State<MausApp> {
  bool get loggedIn => Api.token != null;
  Future<void> logout() async {
    final p = await SharedPreferences.getInstance();
    await p.remove('token');
    await p.remove('adult');
    Api.token = null;
    Api.adult = false;
    setState(() {});
  }
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Maus',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFFF5A1F), brightness: Brightness.dark),
      ),
      home: !loggedIn
          ? LoginPage(onDone: () => setState(() {}))
          : !Api.adult
              ? AgeGatePage(onDone: () => setState(() {}), onLogout: logout)
              : HomePage(onLogout: logout),
    );
  }
}

void snack(BuildContext c, String m) =>
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));

// ---------------- लॉगिन (फोन OTP) ----------------
class LoginPage extends StatefulWidget {
  final VoidCallback onDone;
  const LoginPage({super.key, required this.onDone});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final phone = TextEditingController();
  final code = TextEditingController();
  bool sent = false, busy = false;

  Future<void> send() async {
    if (!RegExp(r'^[6-9]\d{9}$').hasMatch(phone.text)) return snack(context, 'सही 10 अंकों का मोबाइल नंबर डालें');
    setState(() => busy = true);
    try {
      final r = await Api.post('/auth/send-otp', {'phone': '+91${phone.text}'});
      if (r.statusCode == 200) {
        setState(() => sent = true);
      } else {
        snack(context, 'OTP नहीं भेज पाए, थोड़ी देर बाद कोशिश करें');
      }
    } catch (_) {
      snack(context, 'इंटरनेट की दिक्कत');
    }
    setState(() => busy = false);
  }

  Future<void> verify() async {
    setState(() => busy = true);
    try {
      final r = await Api.post('/auth/verify-otp', {'phone': '+91${phone.text}', 'code': code.text});
      if (r.statusCode == 200) {
        Api.token = jsonDecode(r.body)['token'];
        final p = await SharedPreferences.getInstance();
        await p.setString('token', Api.token!);
        widget.onDone();
        return;
      }
      snack(context, 'OTP गलत है या पुराना हो गया');
    } catch (_) {
      snack(context, 'इंटरनेट की दिक्कत');
    }
    setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Text('Maus 🐭', style: TextStyle(fontSize: 40, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            const Text('शॉर्ट और लंबे वीडियो, भारत के लिए'),
            const SizedBox(height: 32),
            TextField(
              controller: phone,
              enabled: !sent,
              keyboardType: TextInputType.phone,
              maxLength: 10,
              decoration: const InputDecoration(prefixText: '+91 ', labelText: 'मोबाइल नंबर', border: OutlineInputBorder()),
            ),
            if (sent)
              TextField(
                controller: code,
                keyboardType: TextInputType.number,
                maxLength: 6,
                decoration: const InputDecoration(labelText: 'OTP', border: OutlineInputBorder()),
              ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: FilledButton(
                onPressed: busy ? null : (sent ? verify : send),
                child: Text(sent ? 'लॉगिन करें' : 'OTP भेजें'),
              ),
            ),
            const SizedBox(height: 16),
            const Text('आगे बढ़कर आप हमारी शर्तें और प्राइवेसी पॉलिसी मानते हैं।',
                textAlign: TextAlign.center, style: TextStyle(fontSize: 12)),
          ]),
        ),
      ),
    );
  }
}

// ---------------- उम्र की जाँच (सिर्फ 18+) ----------------
class AgeGatePage extends StatefulWidget {
  final VoidCallback onDone;
  final Future<void> Function() onLogout;
  const AgeGatePage({super.key, required this.onDone, required this.onLogout});
  @override
  State<AgeGatePage> createState() => _AgeGatePageState();
}

class _AgeGatePageState extends State<AgeGatePage> {
  DateTime? dob;
  bool busy = false;

  Future<void> pick() async {
    final d = await showDatePicker(
      context: context,
      initialDate: DateTime(2000, 1, 1),
      firstDate: DateTime(1920),
      lastDate: DateTime.now(),
      helpText: 'अपनी जन्मतिथि चुनें',
    );
    if (d != null) setState(() => dob = d);
  }

  Future<void> submit() async {
    setState(() => busy = true);
    try {
      final iso = dob!.toIso8601String().substring(0, 10);
      final r = await Api.post('/me/age', {'dob': iso});
      if (r.statusCode == 200) {
        final p = await SharedPreferences.getInstance();
        await p.setBool('adult', true);
        Api.adult = true;
        widget.onDone();
        return;
      }
      if (r.statusCode == 403) {
        if (!mounted) return;
        await showDialog(
          context: context,
          barrierDismissible: false,
          builder: (_) => AlertDialog(
            title: const Text('माफ़ कीजिए'),
            content: const Text('Maus सिर्फ 18 साल या उससे ज़्यादा उम्र के लोगों के लिए है। आपकी सुरक्षा के लिए हम आपको अभी अंदर नहीं ले सकते।'),
            actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('ठीक है'))],
          ),
        );
        await widget.onLogout();
        return;
      }
      if (mounted) snack(context, 'कुछ गड़बड़ हुई, दोबारा कोशिश करें');
    } catch (_) {
      if (mounted) snack(context, 'इंटरनेट की दिक्कत');
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Text('Maus 18+ के लिए है', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            const Text('कृपया सही जन्मतिथि बताएँ। जन्मतिथि हम सेव नहीं करते।', textAlign: TextAlign.center),
            const SizedBox(height: 24),
            OutlinedButton(
              onPressed: pick,
              child: Text(dob == null ? 'जन्मतिथि चुनें' : '${dob!.day}/${dob!.month}/${dob!.year}'),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: FilledButton(onPressed: dob == null || busy ? null : submit, child: const Text('आगे बढ़ें')),
            ),
          ]),
        ),
      ),
    );
  }
}

// ---------------- होम ----------------
class HomePage extends StatelessWidget {
  final VoidCallback onLogout;
  const HomePage({super.key, required this.onLogout});

  Future<void> upload(BuildContext context) async {
    final picked = await ImagePicker().pickVideo(source: ImageSource.gallery);
    if (picked == null) return;
    final file = File(picked.path);
    final size = await file.length();
    if (size > 100 * 1024 * 1024) {
      if (context.mounted) snack(context, 'वीडियो 100 MB से छोटा चुनें');
      return;
    }
    final vc = VideoPlayerController.file(file);
    await vc.initialize();
    final secs = vc.value.duration.inSeconds;
    await vc.dispose();
    if (!context.mounted) return;
    final title = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(secs <= 90 ? 'शॉर्ट वीडियो पोस्ट करें' : 'लंबा वीडियो पोस्ट करें'),
        content: TextField(controller: title, maxLength: 100, decoration: const InputDecoration(hintText: 'शीर्षक / कैप्शन')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('रद्द')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('पोस्ट')),
        ],
      ),
    );
    if (ok != true || !context.mounted) return;
    snack(context, 'अपलोड हो रहा है…');
    try {
      final r = await Api.post('/videos/upload-url', {'title': title.text, 'durationSec': secs, 'sizeBytes': size});
      if (r.statusCode != 200) throw Exception('url');
      final d = jsonDecode(r.body);
      final put = await http.put(Uri.parse(d['uploadUrl']), headers: {'Content-Type': 'video/mp4'}, body: await file.readAsBytes());
      if (put.statusCode >= 300) throw Exception('put');
      await Api.post('/videos/${d['videoId']}/complete');
      if (context.mounted) snack(context, 'वीडियो पोस्ट हो गया ✅ (कुछ देर में दिखेगा)');
    } catch (_) {
      if (context.mounted) snack(context, 'अपलोड नहीं हो पाया, दोबारा कोशिश करें');
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Maus 🐭', style: TextStyle(fontWeight: FontWeight.w900)),
          actions: [IconButton(icon: const Icon(Icons.logout), onPressed: onLogout)],
          bottom: const TabBar(tabs: [Tab(text: 'शॉर्ट'), Tab(text: 'लंबे वीडियो')]),
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => upload(context),
          icon: const Icon(Icons.add),
          label: const Text('अपलोड'),
        ),
        body: const TabBarView(children: [FeedPage(kind: 'short'), FeedPage(kind: 'long')]),
      ),
    );
  }
}

// ---------------- फीड ----------------
class FeedPage extends StatefulWidget {
  final String kind;
  const FeedPage({super.key, required this.kind});
  @override
  State<FeedPage> createState() => _FeedPageState();
}

class _FeedPageState extends State<FeedPage> with AutomaticKeepAliveClientMixin {
  final items = <dynamic>[];
  bool loading = false, done = false, error = false;
  int current = 0;
  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    if (loading || done) return;
    setState(() {
      loading = true;
      error = false;
    });
    try {
      final more = await Api.feed(widget.kind, items.isEmpty ? null : items.last['created_at']);
      items.addAll(more);
      if (more.length < 20) done = true;
    } catch (_) {
      error = true;
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    if (items.isEmpty) {
      return Center(
        child: loading
            ? const CircularProgressIndicator()
            : Column(mainAxisSize: MainAxisSize.min, children: [
                Text(error ? 'वीडियो लोड नहीं हुए' : 'अभी कोई वीडियो नहीं है। पहला आप डालें! 🐭'),
                TextButton(
                    onPressed: () {
                      done = false;
                      load();
                    },
                    child: const Text('दोबारा देखें')),
              ]),
      );
    }
    if (widget.kind == 'short') {
      return PageView.builder(
        scrollDirection: Axis.vertical,
        itemCount: items.length,
        onPageChanged: (i) {
          setState(() => current = i);
          if (i >= items.length - 3) load();
        },
        itemBuilder: (_, i) => VideoCard(key: ValueKey(items[i]['id']), item: items[i], active: i == current, fill: true),
      );
    }
    return ListView.builder(
      itemCount: items.length,
      itemBuilder: (_, i) {
        if (i >= items.length - 2) load();
        return Padding(
          padding: const EdgeInsets.all(10),
          child: AspectRatio(aspectRatio: 16 / 10, child: VideoCard(key: ValueKey(items[i]['id']), item: items[i], active: false, fill: false)),
        );
      },
    );
  }
}

class VideoCard extends StatefulWidget {
  final Map item;
  final bool active, fill;
  const VideoCard({super.key, required this.item, required this.active, required this.fill});
  @override
  State<VideoCard> createState() => _VideoCardState();
}

class _VideoCardState extends State<VideoCard> {
  late final VideoPlayerController c;
  bool ready = false, liked = false, failed = false;
  late int likes;

  @override
  void initState() {
    super.initState();
    likes = (widget.item['like_count'] ?? 0) as int;
    c = VideoPlayerController.networkUrl(Uri.parse(widget.item['url']))
      ..setLooping(true)
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() => ready = true);
        if (widget.active) c.play();
      }).catchError((_) {
        if (mounted) setState(() => failed = true);
      });
  }

  @override
  void didUpdateWidget(VideoCard old) {
    super.didUpdateWidget(old);
    if (!ready) return;
    widget.active ? c.play() : (widget.fill ? c.pause() : null);
  }

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  Future<void> like() async {
    final was = liked;
    setState(() {
      liked = !was;
      likes += was ? -1 : 1;
    });
    try {
      final r = was ? await Api.del('/videos/${widget.item['id']}/like') : await Api.post('/videos/${widget.item['id']}/like');
      if (r.statusCode == 401) throw Exception('login');
    } catch (_) {
      if (mounted) {
        setState(() {
          liked = was;
          likes += was ? 1 : -1;
        });
        snack(context, 'लाइक नहीं हो पाया');
      }
    }
  }

  Future<void> report() async {
    final r = TextEditingController();
    String code = 'other';
    const reasons = {
      'child_safety': 'बच्चों से जुड़ा / बच्चे को नुकसान',
      'sexual': 'अश्लील या यौन कंटेंट',
      'violence': 'हिंसा या खतरनाक चीज़ें',
      'hate': 'नफ़रत या धमकी',
      'spam': 'स्पैम या धोखा',
      'other': 'कुछ और',
    };
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: const Text('वीडियो की शिकायत करें'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            DropdownButton<String>(
              isExpanded: true,
              value: code,
              items: reasons.entries
                  .map((e) => DropdownMenuItem(value: e.key, child: Text(e.value, overflow: TextOverflow.ellipsis)))
                  .toList(),
              onChanged: (v) => setS(() => code = v ?? code),
            ),
            TextField(controller: r, maxLength: 200, decoration: const InputDecoration(hintText: 'और जानकारी (ज़रूरी नहीं)')),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('रद्द')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('भेजें')),
          ],
        ),
      ),
    );
    if (ok == true) {
      await Api.post('/videos/${widget.item['id']}/report', {'reasonCode': code, 'reason': r.text});
      if (mounted) snack(context, 'शिकायत दर्ज हुई, हम जाँच करेंगे');
    }
  }

  @override
  Widget build(BuildContext context) {
    final it = widget.item;
    return ClipRRect(
      borderRadius: BorderRadius.circular(widget.fill ? 0 : 14),
      child: Stack(fit: StackFit.expand, children: [
        const ColoredBox(color: Colors.black),
        if (failed)
          const Center(child: Text('यह वीडियो चल नहीं पाया'))
        else if (!ready)
          const Center(child: CircularProgressIndicator())
        else
          GestureDetector(
            onTap: () => setState(() => c.value.isPlaying ? c.pause() : c.play()),
            child: FittedBox(
              fit: widget.fill ? BoxFit.cover : BoxFit.contain,
              clipBehavior: Clip.hardEdge,
              child: SizedBox(width: c.value.size.width, height: c.value.size.height, child: VideoPlayer(c)),
            ),
          ),
        Positioned(
          left: 0,
          right: 70,
          bottom: 0,
          child: Container(
            padding: const EdgeInsets.fromLTRB(14, 24, 8, 16),
            decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Colors.black87])),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
              Text('@${it['username'] ?? 'maus_user'}', style: const TextStyle(fontWeight: FontWeight.bold)),
              if ((it['title'] ?? '').toString().isNotEmpty) Text(it['title']),
            ]),
          ),
        ),
        Positioned(
          right: 6,
          bottom: 20,
          child: Column(children: [
            IconButton(onPressed: like, icon: Icon(Icons.favorite, size: 32, color: liked ? Colors.redAccent : Colors.white)),
            Text('$likes', style: const TextStyle(fontSize: 12)),
            const SizedBox(height: 8),
            IconButton(onPressed: report, icon: const Icon(Icons.flag_outlined, size: 28)),
          ]),
        ),
      ]),
    );
  }
}
