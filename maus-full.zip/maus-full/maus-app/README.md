# Maus Flutter ऐप

## चलाने के चरण
1. Flutter इंस्टॉल करें, फिर: `flutter create --org in.maus --project-name maus .` (इसी फोल्डर में)
   यह android/ ios/ फोल्डर बना देगा। `lib/main.dart` और `pubspec.yaml` वैसे ही रहने दें।
2. `lib/main.dart` में `apiBase` अपने सर्वर के पते से बदलें।
3. `android/app/src/main/AndroidManifest.xml` में `<manifest>` के अंदर जोड़ें:
   `<uses-permission android:name="android.permission.INTERNET"/>`
4. `flutter pub get && flutter run`
5. Play Store के लिए: `flutter build appbundle`

## ध्यान दें
- बैकएंड में `AUTO_LIVE=1` रखें, जब तक वीडियो प्रोसेसिंग वर्कर नहीं बनता।
- Play Store पर डालने से पहले प्राइवेसी पॉलिसी का पेज और "यूज़र जनरेटेड कंटेंट" की मॉडरेशन व्यवस्था ज़रूरी है।
