# Henri 🤖
Modular AI agent system. Teen sources ka mix:
- **AI Agents Roadmap** → agent loop, tool calling, memory/RAG, multi-agent, evals, observability, gateway, deployment
- **LLM Tools Cheatsheet** → Claude provider, vector store, prompt registry, FastAPI/Docker
- **NVIDIA Open Agent Safety Platform** → guardrails, PII redaction, tool allow-list, SSRF/path sandbox, audit log, rate limit

## Quick start
```bash
pip install -r requirements.txt
cp .env.example .env        # ANTHROPIC_API_KEY daalo
make cli                    # terminal chat
make run                    # http://localhost:8000  (web UI)
make test                   # tests
make docker                 # Docker se chalao
```
Bina API key ke MockLLM chalta hai (testing ke liye).

## Structure
| File | Kaam |
|---|---|
| `henri/llm.py` | Claude + MockLLM |
| `henri/agent.py` | Agent loop + Supervisor (Researcher→Writer) |
| `henri/tools.py` | calculator, now, web_search, web_fetch, read_file, write_file |
| `henri/memory.py` | SQLite history + chunking + vector search (RAG) |
| `henri/safety.py` | Guardrails, PII, rate limit, SSRF, path sandbox |
| `henri/observe.py` | Audit log (`data/audit.jsonl`), counters, latency |
| `henri/evals.py` | Mini eval suite (`/eval`) |
| `henri/api.py` | FastAPI: `/ask` `/ingest` `/history/{user}` `/health` |
| `static/index.html` | Web chat UI |

## API
```bash
curl -X POST localhost:8000/ask -H 'Content-Type: application/json' -H 'X-API-Key: <key>' \
  -d '{"text":"search: latest AI news","user":"me","team":true}'
```

## Aage badhane ke liye
- `memory.embed` ko asli embedding model se badlo, aur `Memory.search` ko Chroma/Qdrant se
- Naye tools: `tools.py` me `Tool(...)` register karo (risky ho to `risky=True`)
- Naye agents: `core.py` me `mk(...)` se banao aur Supervisor me jodo
- Production me `HENRI_API_KEY` zaroor set karo aur HTTPS ke peeche chalao
