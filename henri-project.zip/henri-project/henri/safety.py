"""Safety layer: guardrails, PII redaction, rate limit, SSRF + path sandbox (NVIDIA Agent Safety jaisa)."""
import ipaddress, re, socket, time
from collections import defaultdict, deque
from pathlib import Path
from urllib.parse import urlparse

class Guardrails:
    BLOCK_INPUT = [
        r"ignore (all |any )?(previous|prior) instructions",
        r"reveal.*(system prompt|api key|password|secret)",
        r"(पिछले|सारे) निर्देश(ों)? (को )?(भूल|इग्नोर)",
    ]
    PII = {
        "EMAIL": r"[\w\.-]+@[\w\.-]+\.\w+",
        "AADHAAR": r"\b\d{4}\s?\d{4}\s?\d{4}\b",
        "PHONE": r"(?<!\d)(?:\+91[\s-]?)?[6-9]\d{9}(?!\d)",
    }
    SECRETS = r"(sk-[A-Za-z0-9_\-]{16,}|AKIA[0-9A-Z]{16})"

    def check_input(self, text):
        for p in self.BLOCK_INPUT:
            if re.search(p, text, re.I):
                return False, "Prompt-injection ya secret maangne ki koshish block hui."
        return True, ""

    def redact(self, text):
        text = re.sub(self.SECRETS, "[SECRET_REDACTED]", text)
        for name, p in self.PII.items():
            text = re.sub(p, f"[{name}_REDACTED]", text)
        return text

class RateLimiter:
    def __init__(self, per_min=20):
        self.per_min, self.hits = per_min, defaultdict(deque)

    def allow(self, key):
        now, q = time.time(), self.hits[key]
        while q and now - q[0] > 60:
            q.popleft()
        if len(q) >= self.per_min:
            return False
        q.append(now)
        return True

def safe_url(url):
    """SSRF roko: sirf public http/https."""
    u = urlparse(url)
    if u.scheme not in ("http", "https") or not u.hostname:
        raise ValueError("sirf http/https URL allowed")
    for info in socket.getaddrinfo(u.hostname, None):
        ip = ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
            raise ValueError("private/internal address block hai")
    return url

def safe_path(workspace, rel):
    """Path traversal roko: sirf workspace ke andar."""
    base = Path(workspace).resolve()
    p = (base / rel).resolve()
    if base != p and base not in p.parents:
        raise ValueError("workspace ke bahar access allowed nahi")
    return p
