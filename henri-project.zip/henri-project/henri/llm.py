"""LLM provider layer. Claude (real) + MockLLM (offline testing).
Dono ek hi format lautate hain:
  {"text": str, "tool_calls": [{"id","name","input"}], "raw": [content blocks]}
"""
import re
from .config import settings

class MockLLM:
    name = "mock"

    def chat(self, system, messages, tools=None):
        last = messages[-1]["content"]
        # tool result aaya hai -> final jawab
        if isinstance(last, list):
            res = " | ".join(str(b.get("content", "")) for b in last if b.get("type") == "tool_result")
            text = f"[Mock] Tool se mila: {res}"
            return {"text": text, "tool_calls": [], "raw": [{"type": "text", "text": text}]}
        low = last.lower()
        call = None
        m = re.search(r"calculate\s+(.+)", low)
        if m:
            call = ("calculator", {"expression": m.group(1).strip()})
        elif low.startswith("search:"):
            call = ("web_search", {"query": last[7:].strip()})
        elif "time" in low or "समय" in low:
            call = ("now", {})
        if call:
            blk = {"type": "tool_use", "id": "mock_1", "name": call[0], "input": call[1]}
            return {"text": "", "tool_calls": [blk], "raw": [blk]}
        text = f"[Mock] Maine suna: {last[:200]}"
        return {"text": text, "tool_calls": [], "raw": [{"type": "text", "text": text}]}

class ClaudeLLM:
    name = "claude"

    def __init__(self):
        import anthropic
        self.client = anthropic.Anthropic(api_key=settings.anthropic_key)

    def chat(self, system, messages, tools=None):
        kw = dict(model=settings.model, max_tokens=1500, system=system, messages=messages)
        if tools:
            kw["tools"] = tools
        r = self.client.messages.create(**kw)
        raw = [b.model_dump() for b in r.content]
        calls = [b for b in raw if b["type"] == "tool_use"]
        text = "".join(b["text"] for b in raw if b["type"] == "text")
        return {"text": text, "tool_calls": calls, "raw": raw}

def get_llm():
    if settings.anthropic_key:
        try:
            return ClaudeLLM()
        except Exception as e:  # SDK install nahi hai
            print("Claude load nahi hua, Mock use ho raha hai:", e)
    return MockLLM()
