"""Tool layer: schema-based function calling + allow-list + sandbox."""
import ast, html, operator, re, time, urllib.parse, urllib.request
from dataclasses import dataclass
from typing import Callable, Any
from .config import settings
from .safety import safe_url, safe_path

@dataclass
class Tool:
    name: str
    description: str
    schema: dict
    fn: Callable[..., Any]
    risky: bool = False

class ToolRegistry:
    def __init__(self, tools=None, allow=None):
        self.tools = tools if tools is not None else {}
        self.allow = set(allow) if allow is not None else set(self.tools)

    def register(self, t):
        self.tools[t.name] = t
        self.allow.add(t.name)

    def subset(self, names):
        return ToolRegistry(self.tools, set(names) & set(self.tools))

    def specs(self):
        return [{"name": t.name, "description": t.description, "input_schema": t.schema}
                for t in self.tools.values() if t.name in self.allow]

    def run(self, name, args):
        if name not in self.allow or name not in self.tools:
            return f"ERROR: tool '{name}' allowed nahi hai."
        t = self.tools[name]
        if t.risky and not settings.allow_risky:
            return f"ERROR: '{name}' risky tool hai. HENRI_ALLOW_RISKY=1 karke hi chalega."
        try:
            return t.fn(**(args or {}))
        except Exception as e:
            return f"ERROR: {type(e).__name__}: {e}"

# ---- calculator: eval nahi, safe AST ----
_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
        ast.Pow: operator.pow, ast.Mod: operator.mod, ast.USub: operator.neg, ast.FloorDiv: operator.floordiv}

def _eval(n):
    if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)):
        return n.value
    if isinstance(n, ast.BinOp) and type(n.op) in _OPS:
        a, b = _eval(n.left), _eval(n.right)
        if isinstance(n.op, ast.Pow) and abs(b) > 100:
            raise ValueError("power bahut bada hai")
        return _OPS[type(n.op)](a, b)
    if isinstance(n, ast.UnaryOp) and type(n.op) in _OPS:
        return _OPS[type(n.op)](_eval(n.operand))
    raise ValueError("sirf numbers aur + - * / ** % allowed")

def calculator(expression: str):
    return _eval(ast.parse(expression.strip(), mode="eval").body)

def now():
    return time.strftime("%Y-%m-%d %H:%M:%S")

# ---- web ----
_UA = {"User-Agent": "Mozilla/5.0 (Henri/0.2)"}

def _get(url, limit=400_000):
    safe_url(url)
    req = urllib.request.Request(url, headers=_UA)
    with urllib.request.urlopen(req, timeout=15) as r:
        return r.read(limit).decode("utf-8", errors="ignore")

def _strip_html(s):
    s = re.sub(r"(?is)<(script|style|noscript).*?</\1>", " ", s)
    s = re.sub(r"(?s)<[^>]+>", " ", s)
    return re.sub(r"\s+", " ", html.unescape(s)).strip()

def web_search(query: str, max_results: int = 5):
    page = _get("https://html.duckduckgo.com/html/?q=" + urllib.parse.quote(query))
    out = []
    for m in re.finditer(r'class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>', page, re.S):
        link = m.group(1)
        if "uddg=" in link:
            link = urllib.parse.unquote(link.split("uddg=")[1].split("&")[0])
        out.append(f"{_strip_html(m.group(2))} - {link}")
        if len(out) >= max_results:
            break
    return "\n".join(out) or "koi result nahi mila"

def web_fetch(url: str, max_chars: int = 4000):
    return _strip_html(_get(url))[:max_chars]

# ---- workspace files ----
def read_file(path: str, max_chars: int = 6000):
    return safe_path(settings.workspace, path).read_text(encoding="utf-8", errors="ignore")[:max_chars]

def write_file(path: str, content: str):
    p = safe_path(settings.workspace, path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    return f"{path} likh diya ({len(content)} chars)"

def default_registry():
    r = ToolRegistry()
    s = lambda **p: {"type": "object", "properties": p, "required": list(p)}
    r.register(Tool("calculator", "Math expression solve karo", s(expression={"type": "string"}), calculator))
    r.register(Tool("now", "Abhi ka date aur time", {"type": "object", "properties": {}}, now))
    r.register(Tool("web_search", "Internet par search karo", s(query={"type": "string"}), web_search))
    r.register(Tool("web_fetch", "Kisi public URL ka text padho", s(url={"type": "string"}), web_fetch))
    r.register(Tool("read_file", "Workspace ki file padho", s(path={"type": "string"}), read_file))
    r.register(Tool("write_file", "Workspace me file likho",
                    s(path={"type": "string"}, content={"type": "string"}), write_file, risky=True))
    return r
