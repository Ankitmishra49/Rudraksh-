"""Memory + RAG. SQLite me persistent: chat history + long-term documents (vector search)."""
import json, math, re, sqlite3, hashlib, time
from pathlib import Path

def embed(text, dim=512):
    """Toy hashing embedding (offline chalta hai). Production me bge/voyage/OpenAI embeddings lagao."""
    v = [0.0] * dim
    for tok in re.findall(r"\w+", text.lower()):
        v[int(hashlib.md5(tok.encode()).hexdigest(), 16) % dim] += 1.0
    n = math.sqrt(sum(x * x for x in v)) or 1.0
    return [x / n for x in v]

def cosine(a, b):
    return sum(x * y for x, y in zip(a, b))

def chunk_text(text, size=500, overlap=80):
    """Chunking strategy: overlapping windows."""
    text = text.strip()
    out, i = [], 0
    while i < len(text):
        out.append(text[i:i + size])
        i += size - overlap
    return out

class Memory:
    def __init__(self, db_path):
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(db_path, check_same_thread=False)
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY, user TEXT, role TEXT, content TEXT, ts REAL);
            CREATE TABLE IF NOT EXISTS docs(id INTEGER PRIMARY KEY, user TEXT, source TEXT, text TEXT, emb TEXT, ts REAL);
            CREATE INDEX IF NOT EXISTS i_msg ON messages(user, id);
            CREATE INDEX IF NOT EXISTS i_doc ON docs(user);
        """)

    # short-term
    def add_message(self, user, role, content):
        self.db.execute("INSERT INTO messages(user,role,content,ts) VALUES(?,?,?,?)", (user, role, content, time.time()))
        self.db.commit()

    def history(self, user, n=10):
        rows = self.db.execute("SELECT role,content FROM messages WHERE user=? ORDER BY id DESC LIMIT ?", (user, n)).fetchall()
        msgs = [{"role": r, "content": c} for r, c in reversed(rows)]
        while msgs and msgs[0]["role"] != "user":   # API: pehla message user ka ho
            msgs.pop(0)
        return msgs

    def clear(self, user):
        self.db.execute("DELETE FROM messages WHERE user=?", (user,))
        self.db.commit()

    # long-term (RAG)
    def add_doc(self, user, text, source="note"):
        n = 0
        for ch in chunk_text(text):
            self.db.execute("INSERT INTO docs(user,source,text,emb,ts) VALUES(?,?,?,?,?)",
                            (user, source, ch, json.dumps(embed(ch)), time.time()))
            n += 1
        self.db.commit()
        return n

    def search(self, user, query, k=3, min_score=0.15):
        q = embed(query)
        rows = self.db.execute("SELECT source,text,emb FROM docs WHERE user=?", (user,)).fetchall()
        scored = sorted(((cosine(q, json.loads(e)), s, t) for s, t, e in rows), reverse=True)
        return [(round(sc, 3), s, t) for sc, s, t in scored[:k] if sc >= min_score]

    def recall(self, user, query):
        hits = self.search(user, query)
        return "\n".join(f"- ({s}) {t}" for _, s, t in hits)
