"""FastAPI gateway: auth + rate limit + /ask /ingest /history /health + web UI."""
from pathlib import Path
from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel
from .config import settings
from .core import Henri

app = FastAPI(title="Henri AI Gateway", version="0.2.0")
henri = Henri()
STATIC = Path(__file__).resolve().parent.parent / "static"

def auth(key):
    if settings.api_key and key != settings.api_key:
        raise HTTPException(401, "galat ya missing X-API-Key")

class AskIn(BaseModel):
    text: str
    user: str = "default"
    team: bool = False

class IngestIn(BaseModel):
    text: str
    user: str = "default"
    source: str = "upload"

@app.get("/")
def index():
    return FileResponse(STATIC / "index.html")

@app.post("/ask")
def ask(body: AskIn, x_api_key: str = Header(default="")):
    auth(x_api_key)
    return {"answer": henri.ask(body.text, body.user, body.team)}

@app.post("/ingest")
def ingest(body: IngestIn, x_api_key: str = Header(default="")):
    auth(x_api_key)
    return {"chunks": henri.ingest(body.text, body.user, body.source)}

@app.get("/history/{user}")
def history(user: str, x_api_key: str = Header(default="")):
    auth(x_api_key)
    return henri.memory.history(user, 50)

@app.delete("/history/{user}")
def clear(user: str, x_api_key: str = Header(default="")):
    auth(x_api_key)
    henri.memory.clear(user)
    return {"ok": True}

@app.get("/health")
def health():
    return {"status": "ok", "llm": henri.llm.name, "stats": henri.obs.stats()}
