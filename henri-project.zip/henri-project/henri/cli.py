from .core import Henri
from .evals import run_evals

HELP = "Commands: /team <sawal> | /ingest <text> | /clear | /eval | /stats | /quit"

def main():
    h, user = Henri(), "cli"
    print(f"Henri taiyaar hai ({h.llm.name}). {HELP}")
    while True:
        try:
            q = input("\nTum: ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not q: continue
        if q == "/quit": break
        if q == "/eval": print(run_evals(h))
        elif q == "/stats": print(h.obs.stats())
        elif q == "/clear": h.memory.clear(user); print("history saaf")
        elif q.startswith("/ingest "): print(h.ingest(q[8:], user), "chunks save hue")
        elif q.startswith("/team "): print("Henri:", h.ask(q[6:], user, team=True))
        elif q == "/help": print(HELP)
        else: print("Henri:", h.ask(q, user))

if __name__ == "__main__":
    main()
