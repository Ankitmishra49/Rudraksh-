"""Henri = sab layers ko jodne wala AI Gateway."""
import uuid
from . import prompts
from .agent import Agent, Supervisor
from .config import settings
from .llm import get_llm
from .memory import Memory
from .observe import Observer
from .safety import Guardrails, RateLimiter
from .tools import default_registry

class Henri:
    def __init__(self):
        self.llm = get_llm()
        self.memory = Memory(settings.db_path)
        self.obs = Observer(settings.audit_log)
        self.guard = Guardrails()
        self.limiter = RateLimiter(settings.rate_per_min)
        reg = default_registry()
        mk = lambda n, p, r: Agent(n, p, self.llm, r, self.memory, self.guard, self.obs)
        self.main = mk("henri", prompts.get("henri_system"), reg)
        self.team = Supervisor(
            mk("researcher", prompts.get("researcher"), reg.subset({"web_search", "web_fetch", "read_file", "calculator"})),
            mk("writer", prompts.get("writer"), reg.subset(set())),
        )

    def ask(self, text, user="default", team=False):
        if not self.limiter.allow(user):
            self.obs.log("rate_limited", user=user)
            return "Bahut zyada requests, thodi der baad try karo."
        self.obs.log("request", user=user, id=uuid.uuid4().hex[:8], chars=len(text))
        return self.team.run(user, text) if team else self.main.run(user, text)

    def ingest(self, text, user="default", source="upload"):
        return self.memory.add_doc(user, self.guard.redact(text), source)
