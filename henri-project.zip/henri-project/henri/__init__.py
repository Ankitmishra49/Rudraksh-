"""Henri - modular AI agent system."""
__version__ = "0.2.0"
