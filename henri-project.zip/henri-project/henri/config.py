import os
from pathlib import Path

def _load_env(path=".env"):
    p = Path(path)
    if not p.exists():
        return
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))

_load_env()

class Settings:
    anthropic_key = os.getenv("ANTHROPIC_API_KEY", "")
    model = os.getenv("HENRI_MODEL", "claude-sonnet-4-5")
    api_key = os.getenv("HENRI_API_KEY", "")            # khali = auth band
    db_path = os.getenv("HENRI_DB", "data/henri.db")
    workspace = os.getenv("HENRI_WORKSPACE", "workspace")
    audit_log = os.getenv("HENRI_AUDIT", "data/audit.jsonl")
    rate_per_min = int(os.getenv("HENRI_RATE_PER_MIN", "20"))
    allow_risky = os.getenv("HENRI_ALLOW_RISKY", "0") == "1"
    max_steps = int(os.getenv("HENRI_MAX_STEPS", "6"))
    history_n = int(os.getenv("HENRI_HISTORY", "10"))

settings = Settings()
