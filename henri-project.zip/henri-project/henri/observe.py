import json, time
from collections import defaultdict
from pathlib import Path

class Observer:
    """Audit log + counters + latency (Observability layer)."""
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.counts = defaultdict(int)
        self.latency = []

    def log(self, event, **data):
        self.counts[event] += 1
        if event == "answer" and "latency" in data:
            self.latency.append(data["latency"])
        rec = {"ts": round(time.time(), 3), "event": event, **data}
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False, default=str) + "\n")

    def stats(self):
        lat = self.latency[-100:]
        return {"counts": dict(self.counts),
                "avg_latency": round(sum(lat) / len(lat), 3) if lat else 0}
