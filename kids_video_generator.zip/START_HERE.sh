#!/bin/bash

# ============================================================
# KIDS VIDEO GENERATOR - START HERE
# This script will set up everything and test it
# ============================================================

set -e  # Exit on error

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}╔════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║  KIDS VIDEO GENERATOR - QUICK START                  ║${NC}"
echo -e "${BLUE}║  This script will install and test everything        ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════╝${NC}"
echo ""

# ============================================================
# Check Prerequisites
# ============================================================
echo -e "${YELLOW}[1/5] Checking Prerequisites...${NC}"

if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js not found!${NC}"
    echo "Install from: https://nodejs.org"
    exit 1
fi

if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ Python 3 not found!${NC}"
    echo "Install from: https://python.org"
    exit 1
fi

echo -e "${GREEN}✅ Node.js: $(node --version)${NC}"
echo -e "${GREEN}✅ Python: $(python3 --version)${NC}"
echo ""

# ============================================================
# Create Directories
# ============================================================
echo -e "${YELLOW}[2/5] Setting up directories...${NC}"

mkdir -p videos logs temp config
echo -e "${GREEN}✅ Directories created${NC}"
echo ""

# ============================================================
# Install Dependencies
# ============================================================
echo -e "${YELLOW}[3/5] Installing dependencies...${NC}"

if [ -f "package.json" ]; then
    npm install --quiet
    echo -e "${GREEN}✅ Node dependencies installed${NC}"
else
    echo -e "${YELLOW}⚠️  package.json not found, skipping npm${NC}"
fi

pip3 install -q gtts requests 2>/dev/null || true
echo -e "${GREEN}✅ Python dependencies installed${NC}"
echo ""

# ============================================================
# Create .env File
# ============================================================
echo -e "${YELLOW}[4/5] Creating configuration...${NC}"

if [ ! -f ".env" ]; then
    cat > .env << 'EOF'
PORT=3000
NODE_ENV=development
GOOGLE_API_KEY=demo_key
YOUTUBE_CLIENT_ID=demo_id
YOUTUBE_CLIENT_SECRET=demo_secret
VIDEO_QUALITY=1080p
VIDEO_FPS=30
DEFAULT_LANGUAGES=en,hi,es,fr,de
EOF
    echo -e "${GREEN}✅ .env file created${NC}"
else
    echo -e "${YELLOW}✓ .env already exists${NC}"
fi
echo ""

# ============================================================
# Test Node Server
# ============================================================
echo -e "${YELLOW}[5/5] Testing server...${NC}"

if [ -f "kids_video_generator.js" ]; then
    echo "Starting server..."
    timeout 5 node kids_video_generator.js &> /dev/null || true
    
    # Give server a moment to start
    sleep 2
    
    # Test server
    if curl -s http://localhost:3000/ &>/dev/null; then
        echo -e "${GREEN}✅ Server is working!${NC}"
        killall node 2>/dev/null || true
    else
        echo -e "${YELLOW}⚠️  Could not connect to server (this is OK for testing)${NC}"
    fi
else
    echo -e "${YELLOW}⚠️  kids_video_generator.js not found${NC}"
fi

echo ""
echo -e "${GREEN}╔════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║  SETUP COMPLETE! ✅                                   ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════════════════════╝${NC}"
echo ""

echo -e "${BLUE}NEXT STEPS:${NC}"
echo ""
echo "1. Read the installation guide:"
echo -e "   ${YELLOW}cat INSTALL_NOW.md${NC}"
echo ""
echo "2. Start the server (Terminal 1):"
echo -e "   ${YELLOW}npm start${NC}"
echo ""
echo "3. Generate videos (Terminal 2):"
echo -e "   ${YELLOW}python3 video_generator_fixed.py${NC}"
echo ""
echo "4. Check results:"
echo -e "   ${YELLOW}ls -la videos/${NC}"
echo ""
echo -e "${GREEN}Everything is ready! 🚀${NC}"
