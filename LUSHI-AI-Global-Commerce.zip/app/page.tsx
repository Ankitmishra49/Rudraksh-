'use client';
import {useState} from 'react';
import {Bot, Globe2, Link2, TrendingUp, ShoppingBag, ShieldCheck, Zap, Search, Settings, BarChart3} from 'lucide-react';

const products=[
 {name:"Smart Fitness Watch",market:"Global",price:"$39.90",commission:"8.5%",score:"94"},
 {name:"Portable Solar Charger",market:"India / EU",price:"$24.50",commission:"11.0%",score:"91"},
 {name:"Wireless Earbuds Pro",market:"US / UK",price:"$29.99",commission:"7.2%",score:"88"},
 {name:"AI Desk Lamp",market:"Worldwide",price:"$44.00",commission:"12.4%",score:"86"}
];
export default function Home(){
 const [auto,setAuto]=useState(true); const [tab,setTab]=useState("Overview");
 return <main>
  <aside><div className="brand"><div className="logo">L</div><div><b>LUSHI</b><small>AI COMMERCE</small></div></div>
   {["Overview","Product Scout","Marketing AI","Affiliate Links","Orders","Analytics","Sellers","Integrations","Settings"].map(x=><button className={tab===x?"nav active":"nav"} onClick={()=>setTab(x)} key={x}>{x}</button>)}
   <div className="sidebottom"><ShieldCheck size={17}/> Secure automation</div>
  </aside>
  <section className="content"><header><div><p className="eyebrow">GLOBAL COMMERCE CONTROL CENTER</p><h1>{tab}</h1></div><button className={auto?"pilot on":"pilot"} onClick={()=>setAuto(!auto)}><span/> AUTO PILOT {auto?"ON":"OFF"}</button></header>
   <div className="hero"><div><p className="eyebrow">LUSHI INTELLIGENCE ENGINE</p><h2>One AI. Every Market.<br/><em>Global Commerce.</em></h2><p className="muted">Discover products, generate compliant affiliate campaigns and monitor revenue from one intelligent workspace.</p><button className="primary"><Zap size={16}/> Run AI Scan</button></div><div className="orb"><Globe2 size={115}/><div className="orbit o1"/><div className="orbit o2"/></div></div>
   <div className="stats">{[["Live Products","12,842","+18.4%",ShoppingBag],["Tracked Clicks","284.6K","+24.1%",Link2],["Conversions","8,492","+12.8%",TrendingUp],["Commission","$48,290","+31.6%",BarChart3]].map(([a,b,c,I])=><div className="stat" key={a as string}><I size={19}/><small>{a}</small><strong>{b}</strong><span>{c}</span></div>)}</div>
   <div className="grid"><div className="panel wide"><div className="panelhead"><div><h3>AI Product Opportunities</h3><p className="muted">Ranked by demand, margin and commission potential</p></div><button className="ghost"><Search size={15}/> Discover</button></div><div className="table">{products.map((p,i)=><div className="row" key={p.name}><div className="producticon">{i+1}</div><div className="pname"><b>{p.name}</b><small>{p.market}</small></div><b>{p.price}</b><span className="green">{p.commission}</span><span className="score">{p.score}</span><button className="mini">Promote</button></div>)}</div></div>
   <div className="panel"><div className="panelhead"><h3>Agent Status</h3><Settings size={16}/></div>{[["Scout","Scanning global feeds"],["Content","24 campaigns queued"],["Link","All systems normal"],["Guard","No critical alerts"]].map(x=><div className="agent" key={x[0]}><span className="dot"/><div><b>{x[0]} AI</b><small>{x[1]}</small></div><span className="live">LIVE</span></div>)}</div></div>
   <footer>© 2026 LUSHI AI · Built for compliant, permission-based commerce automation</footer>
  </section>
 </main>
}