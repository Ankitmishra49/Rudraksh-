# LUSHI AI Global Commerce Dashboard

## Run locally
1. Install Node.js 18+
2. Open terminal in this folder
3. Run `npm install`
4. Run `npm run dev`
5. Open http://localhost:3000

This is a production-style frontend starter. Connect approved affiliate APIs, databases, authentication, payment/payout services and AI provider keys before live commerce use. Never scrape or automate marketplaces against their terms.
