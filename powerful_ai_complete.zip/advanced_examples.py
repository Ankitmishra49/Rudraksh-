"""
╔═══════════════════════════════════════════════════════════════════════════╗
║              POWERFUL AI - ADVANCED EXAMPLES & INTEGRATIONS               ║
║                     Production Ready Use Cases                            ║
╚═══════════════════════════════════════════════════════════════════════════╝
"""

import json
from typing import Dict, List, Any
from powerful_ai import (
    PowerfulAI, Config, TextAnalyzer, CodeGenerator, 
    DataProcessor, Validator, logger
)


# ═══════════════════════════════════════════════════════════════════════════
# Example 1: Customer Feedback Analysis System
# ═══════════════════════════════════════════════════════════════════════════

class CustomerFeedbackAnalyzer:
    """Analyze customer feedback using Powerful AI"""
    
    def __init__(self):
        self.ai = PowerfulAI()
        self.analyzer = self.ai.text_analyzer
    
    def analyze_feedback(self, feedbacks: List[str]) -> Dict[str, Any]:
        """Analyze multiple customer feedbacks"""
        try:
            results = {
                "total_feedbacks": len(feedbacks),
                "analyses": [],
                "summary": {
                    "positive": 0,
                    "negative": 0,
                    "neutral": 0,
                    "avg_word_count": 0
                }
            }
            
            total_words = 0
            
            for i, feedback in enumerate(feedbacks, 1):
                analysis = self.analyzer.analyze_text(feedback)
                results["analyses"].append({
                    "id": i,
                    "feedback": feedback[:50] + "..." if len(feedback) > 50 else feedback,
                    "sentiment": analysis["sentiment"],
                    "keywords": analysis["keywords"][:3],
                    "word_count": analysis["word_count"]
                })
                
                # Update counts
                if analysis["sentiment"] == "POSITIVE":
                    results["summary"]["positive"] += 1
                elif analysis["sentiment"] == "NEGATIVE":
                    results["summary"]["negative"] += 1
                else:
                    results["summary"]["neutral"] += 1
                
                total_words += analysis["word_count"]
            
            results["summary"]["avg_word_count"] = total_words / len(feedbacks) if feedbacks else 0
            
            logger.info(f"Analyzed {len(feedbacks)} customer feedbacks")
            return results
        
        except Exception as e:
            logger.error(f"Feedback analysis error: {e}")
            return {"error": str(e)}


# ═══════════════════════════════════════════════════════════════════════════
# Example 2: Automated Code Generation System
# ═══════════════════════════════════════════════════════════════════════════

class AutoCodeGenerator:
    """Generate production-ready code automatically"""
    
    def __init__(self):
        self.ai = PowerfulAI()
        self.generator = self.ai.code_generator
    
    def generate_data_handler(self, model_name: str, fields: List[str]) -> str:
        """Generate data handler code"""
        try:
            code = f'''
class {model_name}Handler:
    """Auto-generated handler for {model_name}"""
    
    def __init__(self):
        self.fields = {fields}
        self.logger = logger
    
    def validate_input(self, data: dict) -> bool:
        """Validate input data"""
        try:
            for field in self.fields:
                if field not in data:
                    raise ValueError(f"Missing field: {{field}}")
            return True
        except Exception as e:
            self.logger.error(f"Validation error: {{e}}")
            return False
    
    def process(self, data: dict) -> dict:
        """Process the data"""
        try:
            if not self.validate_input(data):
                return {{"error": "Invalid input"}}
            return {{"status": "success", "processed": True}}
        except Exception as e:
            self.logger.error(f"Processing error: {{e}}")
            return {{"error": str(e)}}
'''
            logger.info(f"Generated code for {model_name}")
            return code
        
        except Exception as e:
            logger.error(f"Code generation error: {e}")
            return ""


# ═══════════════════════════════════════════════════════════════════════════
# Example 3: Data Quality Monitoring System
# ═══════════════════════════════════════════════════════════════════════════

class DataQualityMonitor:
    """Monitor and improve data quality"""
    
    def __init__(self):
        self.ai = PowerfulAI()
        self.processor = self.ai.data_processor
        self.validator = self.ai.validator
    
    def check_data_quality(self, data: List[Dict]) -> Dict[str, Any]:
        """Comprehensive data quality check"""
        try:
            quality_report = {
                "timestamp": self.ai.logger.name,
                "total_records": len(data),
                "quality_metrics": {},
                "issues": [],
                "recommendations": []
            }
            
            # Process data
            analysis = self.processor.process_data(data)
            
            # Check for missing values
            missing = analysis.get("missing_values", {})
            if missing:
                quality_report["issues"].append(f"Missing values found: {missing}")
                quality_report["recommendations"].append("Fill missing values with appropriate defaults")
            
            # Check data consistency
            completeness = (len(data) - len(missing)) / len(data) * 100 if data else 0
            quality_report["quality_metrics"]["completeness"] = completeness
            
            if completeness < 90:
                quality_report["recommendations"].append("Data completeness is below 90%")
            
            logger.info(f"Data quality check completed: {completeness}% complete")
            return quality_report
        
        except Exception as e:
            logger.error(f"Data quality check error: {e}")
            return {"error": str(e)}


# ═══════════════════════════════════════════════════════════════════════════
# Example 4: User Input Validation Pipeline
# ═══════════════════════════════════════════════════════════════════════════

class UserInputValidator:
    """Validate user input from multiple sources"""
    
    def __init__(self):
        self.ai = PowerfulAI()
        self.validator = self.ai.validator
    
    def validate_user_registration(self, user_data: Dict[str, Any]) -> Dict[str, Any]:
        """Validate complete user registration data"""
        try:
            validation_results = {
                "is_valid": True,
                "errors": [],
                "warnings": [],
                "validated_fields": {}
            }
            
            # Email validation
            email = user_data.get("email", "")
            if not self.validator.validate_email(email):
                validation_results["errors"].append(f"Invalid email: {email}")
                validation_results["is_valid"] = False
            else:
                validation_results["validated_fields"]["email"] = "✓ Valid"
            
            # Phone validation
            phone = user_data.get("phone", "")
            if phone and not self.validator.validate_phone(phone):
                validation_results["warnings"].append(f"Invalid phone format: {phone}")
            else:
                validation_results["validated_fields"]["phone"] = "✓ Valid" if phone else "Not provided"
            
            # Website validation
            website = user_data.get("website", "")
            if website and not self.validator.validate_url(website):
                validation_results["warnings"].append(f"Invalid website URL: {website}")
            else:
                validation_results["validated_fields"]["website"] = "✓ Valid" if website else "Not provided"
            
            # Name validation
            name = user_data.get("name", "")
            if not name or len(name) < 2:
                validation_results["errors"].append("Name must be at least 2 characters")
                validation_results["is_valid"] = False
            else:
                validation_results["validated_fields"]["name"] = "✓ Valid"
            
            logger.info(f"User validation completed: {validation_results['is_valid']}")
            return validation_results
        
        except Exception as e:
            logger.error(f"User validation error: {e}")
            return {"error": str(e), "is_valid": False}


# ═══════════════════════════════════════════════════════════════════════════
# Example 5: Content Analysis & SEO Tool
# ═══════════════════════════════════════════════════════════════════════════

class ContentSEOAnalyzer:
    """Analyze content for SEO optimization"""
    
    def __init__(self):
        self.ai = PowerfulAI()
        self.analyzer = self.ai.text_analyzer
    
    def analyze_content(self, content: str, target_keywords: List[str] = None) -> Dict[str, Any]:
        """Analyze content for SEO"""
        try:
            analysis = self.analyzer.analyze_text(content)
            
            seo_report = {
                "overall_score": 0,
                "readability": {},
                "keyword_analysis": {},
                "seo_recommendations": [],
                "content_stats": analysis
            }
            
            # Readability metrics
            avg_word_length = analysis["avg_word_length"]
            seo_report["readability"]["avg_word_length"] = avg_word_length
            
            if avg_word_length > 5:
                seo_report["seo_recommendations"].append("Use shorter, simpler words for better readability")
            
            # Word count check
            word_count = analysis["word_count"]
            seo_report["readability"]["word_count"] = word_count
            
            if word_count < 300:
                seo_report["seo_recommendations"].append("Content should be at least 300 words for better SEO")
            elif word_count > 2000:
                seo_report["seo_recommendations"].append("Consider breaking content into multiple articles")
            
            # Keyword analysis
            keywords = analysis["keywords"]
            seo_report["keyword_analysis"]["found_keywords"] = keywords
            
            if target_keywords:
                found_targets = [kw for kw in target_keywords if kw.lower() in content.lower()]
                seo_report["keyword_analysis"]["target_keywords_found"] = found_targets
                seo_report["keyword_analysis"]["keyword_coverage"] = len(found_targets) / len(target_keywords) * 100
            
            # Calculate overall score
            score = 50
            if word_count >= 300:
                score += 15
            if avg_word_length <= 5:
                score += 15
            if len(keywords) >= 5:
                score += 20
            
            seo_report["overall_score"] = min(score, 100)
            
            logger.info(f"SEO analysis completed: Score {seo_report['overall_score']}/100")
            return seo_report
        
        except Exception as e:
            logger.error(f"SEO analysis error: {e}")
            return {"error": str(e)}


# ═══════════════════════════════════════════════════════════════════════════
# Example 6: Batch Processing System
# ═══════════════════════════════════════════════════════════════════════════

class BatchProcessor:
    """Process large batches of data efficiently"""
    
    def __init__(self):
        self.ai = PowerfulAI()
        self.config = self.ai.config
    
    def process_batch(self, data: List[Dict], processor_type: str) -> Dict[str, Any]:
        """Process data in batches"""
        try:
            batch_size = self.config.get("batch_size", 100)
            results = {
                "total_items": len(data),
                "batch_size": batch_size,
                "batches_processed": 0,
                "results": []
            }
            
            for i in range(0, len(data), batch_size):
                batch = data[i:i + batch_size]
                
                if processor_type == "text_analysis":
                    batch_result = self.ai.text_analyzer.analyze_text(
                        " ".join(str(item) for item in batch)
                    )
                elif processor_type == "data_processing":
                    batch_result = self.ai.data_processor.process_data(batch)
                else:
                    batch_result = {"error": "Unknown processor type"}
                
                results["results"].append(batch_result)
                results["batches_processed"] += 1
            
            logger.info(f"Batch processing completed: {results['batches_processed']} batches")
            return results
        
        except Exception as e:
            logger.error(f"Batch processing error: {e}")
            return {"error": str(e)}


# ═══════════════════════════════════════════════════════════════════════════
# DEMO: Run All Examples
# ═══════════════════════════════════════════════════════════════════════════

def run_all_examples():
    """Run all advanced examples"""
    print("\n" + "="*80)
    print("POWERFUL AI - ADVANCED EXAMPLES & INTEGRATIONS".center(80))
    print("="*80 + "\n")
    
    # Example 1: Customer Feedback Analysis
    print("✓ Example 1: Customer Feedback Analysis")
    print("-" * 80)
    feedback_analyzer = CustomerFeedbackAnalyzer()
    feedbacks = [
        "यह product बहुत अच्छा है और काफी powerful है।",
        "Support team बहुत helpful नहीं था।",
        "मुझे यह service का अनुभव ठीक-ठाक लगा।",
        "Excellent product! बिल्कुल शानदार है।"
    ]
    result = feedback_analyzer.analyze_feedback(feedbacks)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    print()
    
    # Example 2: Code Generation
    print("✓ Example 2: Auto Code Generation")
    print("-" * 80)
    code_gen = AutoCodeGenerator()
    generated_code = code_gen.generate_data_handler("UserModel", ["id", "name", "email"])
    print(generated_code)
    print()
    
    # Example 3: Data Quality
    print("✓ Example 3: Data Quality Monitoring")
    print("-" * 80)
    data_quality = DataQualityMonitor()
    sample_data = [
        {"id": 1, "name": "Product A", "price": 100, "stock": 50},
        {"id": 2, "name": "Product B", "price": 200, "stock": None},
        {"id": 3, "name": "Product C", "price": None, "stock": 75}
    ]
    quality_report = data_quality.check_data_quality(sample_data)
    print(json.dumps(quality_report, indent=2, ensure_ascii=False))
    print()
    
    # Example 4: User Validation
    print("✓ Example 4: User Input Validation")
    print("-" * 80)
    user_validator = UserInputValidator()
    user_data = {
        "name": "John Doe",
        "email": "john@example.com",
        "phone": "+91 9876543210",
        "website": "https://www.example.com"
    }
    validation = user_validator.validate_user_registration(user_data)
    print(json.dumps(validation, indent=2, ensure_ascii=False))
    print()
    
    # Example 5: SEO Analysis
    print("✓ Example 5: Content SEO Analysis")
    print("-" * 80)
    seo_analyzer = ContentSEOAnalyzer()
    sample_content = """
    यह एक Powerful AI System है जो सभी काम को automation से पूरा कर सकता है।
    यह system बहुत advanced है और उच्च quality का code generate करता है।
    Data analysis, text processing, code generation सभी features हैं।
    Error handling अच्छी है और logging भी complete है।
    यह production ready application है जिसे directly use किया जा सकता है।
    """
    seo_report = seo_analyzer.analyze_content(sample_content, ["AI", "System", "Python"])
    print(json.dumps(seo_report, indent=2, ensure_ascii=False))
    print()
    
    # Example 6: Batch Processing
    print("✓ Example 6: Batch Processing")
    print("-" * 80)
    batch_proc = BatchProcessor()
    batch_data = [
        {"text": "Good product"},
        {"text": "Bad experience"},
        {"text": "Excellent service"}
    ]
    batch_result = batch_proc.process_batch(batch_data, "data_processing")
    print(json.dumps(batch_result, indent=2, ensure_ascii=False))
    print()
    
    print("="*80)
    print("ALL EXAMPLES COMPLETED SUCCESSFULLY".center(80))
    print("="*80 + "\n")


if __name__ == "__main__":
    try:
        run_all_examples()
    except Exception as e:
        logger.critical(f"Example execution error: {e}")
