"""
Setup configuration for Powerful AI Package

This file allows installation of Powerful AI as a Python package.

Usage:
    pip install -e .
    
Or:
    python setup.py install
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text(encoding="utf-8") if readme_file.exists() else ""

# Read requirements
requirements_file = Path(__file__).parent / "requirements.txt"
if requirements_file.exists():
    requirements = [
        line.strip() 
        for line in requirements_file.read_text(encoding="utf-8").split('\n')
        if line.strip() and not line.startswith('#')
    ]
else:
    requirements = []

setup(
    # Package Information
    name="powerful-ai",
    version="1.0.0",
    description="Professional AI Integration Platform - Complete Multi-Functional AI System",
    long_description=long_description,
    long_description_content_type="text/markdown",
    
    # Author Information
    author="Powerful AI Development Team",
    author_email="team@powerfulai.com",
    url="https://github.com/powerfulai/powerful-ai",
    
    # License
    license="MIT",
    
    # Classifier
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Natural Language :: English",
    ],
    
    # Keywords
    keywords=[
        "AI", "Artificial Intelligence", "Text Analysis", "Code Generation",
        "Data Processing", "Validation", "Machine Learning", "NLP",
        "Production-Ready", "Python"
    ],
    
    # Python Requirements
    python_requires=">=3.8",
    
    # Dependencies
    install_requires=requirements,
    
    # Extra Requirements
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=3.0.0",
            "black>=21.0",
            "flake8>=3.9.0",
            "mypy>=0.910",
        ],
        "docs": [
            "sphinx>=4.0.0",
            "sphinx-rtd-theme>=1.0.0",
        ],
    },
    
    # Packages
    packages=find_packages(where="."),
    
    # Include package data
    include_package_data=True,
    
    # Entry points (if you want command-line access)
    entry_points={
        "console_scripts": [
            "powerful-ai=powerful_ai:main",
        ],
    },
    
    # Project URLs
    project_urls={
        "Documentation": "https://github.com/powerfulai/powerful-ai/wiki",
        "Source": "https://github.com/powerfulai/powerful-ai",
        "Tracker": "https://github.com/powerfulai/powerful-ai/issues",
    },
    
    # Additional metadata
    zip_safe=False,
)

"""
╔═══════════════════════════════════════════════════════════════════════════╗
║                    INSTALLATION INSTRUCTIONS                              ║
╚═══════════════════════════════════════════════════════════════════════════╝

1. DEVELOPMENT INSTALLATION (Editable mode):
   pip install -e .

2. REGULAR INSTALLATION:
   pip install .

3. WITH DEVELOPMENT TOOLS:
   pip install -e ".[dev]"

4. WITH DOCUMENTATION:
   pip install -e ".[docs]"

5. WITH ALL EXTRAS:
   pip install -e ".[dev,docs]"

6. UNINSTALL:
   pip uninstall powerful-ai

╔═══════════════════════════════════════════════════════════════════════════╗
║                         VERIFICATION                                      ║
╚═══════════════════════════════════════════════════════════════════════════╝

After installation, verify with:

    python -c "from powerful_ai import PowerfulAI; print('✓ Installation successful')"

╔═══════════════════════════════════════════════════════════════════════════╗
║                      SYSTEM REQUIREMENTS                                   ║
╚═══════════════════════════════════════════════════════════════════════════╝

- Python 3.8 or higher
- pip (Python package manager)
- Virtual environment (recommended)
- ~100MB free disk space

╔═══════════════════════════════════════════════════════════════════════════╗
║                      SUPPORTED PLATFORMS                                   ║
╚═══════════════════════════════════════════════════════════════════════════╝

✅ Windows (7, 8, 10, 11)
✅ Linux (Ubuntu, Debian, CentOS, Fedora)
✅ macOS (Intel & Apple Silicon)
✅ Docker
✅ Cloud Platforms (AWS, GCP, Azure)
"""
