# GAGAN AI — Micro SaaS Starter

A starter project containing a Next.js frontend and a FastAPI backend with an optional AI content generation endpoint.

## Included
- Responsive dark landing page
- AI prompt interface connected to FastAPI
- Tool cards and sample pricing UI
- FastAPI health endpoint and AI generation endpoint
- Example environment files

## Important: current scope
This is a starter scaffold, **not a complete production SaaS**. Authentication, PostgreSQL persistence, affiliate-network API integrations, verified payments/subscriptions, admin authorization, social-platform publishing, per-user rate limiting, and billing/webhook handling are not implemented (a basic per-IP rate limit exists on the AI endpoint; change it with `RATE_LIMIT_PER_MINUTE`). Pricing buttons are placeholders. Do not accept real payments or store sensitive user data until these features and security controls are built and tested.

## Requirements
- Node.js 20.9+
- Python 3.10+
- An AI provider API key if you want AI generation to work

## Run locally

### 1. Backend
Open a terminal:

```bash
cd backend
python -m venv .venv
```

Activate the virtual environment:
- Windows PowerShell: `.venv\Scripts\Activate.ps1`
- macOS/Linux/Android terminal: `source .venv/bin/activate`

Install and configure:

```bash
pip install -r requirements.txt
cp .env.example .env
```

Edit `backend/.env` and set `OPENAI_API_KEY` to your own key. Keep this key on the server only.

Start the API:

```bash
uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

API docs: http://127.0.0.1:8000/docs

### 2. Frontend
In a second terminal:

```bash
cd frontend
npm install
cp .env.example .env.local
npm run dev
```

Open http://localhost:3000

If your backend is hosted elsewhere, set `NEXT_PUBLIC_API_URL` to its HTTPS base URL and rebuild/redeploy the frontend.

## Deploy
- Frontend: deploy the `frontend` directory as a Next.js project on Vercel.
- Backend: deploy the `backend` directory to a Python-compatible hosting provider that supports FastAPI.
- Set `OPENAI_API_KEY`, `OPENAI_MODEL`, and `FRONTEND_ORIGIN` as backend environment variables.
- Set `NEXT_PUBLIC_API_URL` as a frontend environment variable to the deployed backend URL, then redeploy.
- Configure HTTPS and restrict CORS to your exact frontend domain.

Do not use wildcard CORS with credentials. Do not put provider keys in browser code or commit `.env` files.

## License
Use and modify as needed. Check the licenses and terms of any third-party services you integrate.
