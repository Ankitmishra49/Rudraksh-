import os
import time
import logging
from collections import defaultdict, deque
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

load_dotenv()
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("gagan-ai")

app = FastAPI(title="GAGAN AI API", version="1.0.0")

origins = [
    origin.strip()
    for origin in os.getenv(
        "FRONTEND_ORIGIN",
        "http://localhost:3000,http://127.0.0.1:3000",
    ).split(",")
    if origin.strip()
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type", "Authorization"],
)

RATE_LIMIT = int(os.getenv("RATE_LIMIT_PER_MINUTE", "10"))
_hits: dict[str, deque] = defaultdict(deque)


def check_rate_limit(client_id: str) -> None:
    now = time.time()
    window = _hits[client_id]
    while window and now - window[0] > 60:
        window.popleft()
    if len(window) >= RATE_LIMIT:
        raise HTTPException(status_code=429, detail="Too many requests. Please wait a minute.")
    window.append(now)


class GenerateRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=4000)

@app.get("/")
def root():
    return {"name": "GAGAN AI API", "status": "running"}

@app.get("/health")
def health():
    return {"status": "healthy"}

@app.post("/api/ai/generate")
def generate_content(request: GenerateRequest, http_request: Request):
    client_id = http_request.client.host if http_request.client else "unknown"
    check_rate_limit(client_id)
    prompt = request.prompt.strip()
    if not prompt:
        raise HTTPException(status_code=422, detail="Prompt cannot be empty.")

    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise HTTPException(
            status_code=503,
            detail="AI API key is not configured. Set OPENAI_API_KEY on the server.",
        )

    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
        response = client.responses.create(
            model=os.getenv("OPENAI_MODEL", "gpt-5"),
            instructions=(
                "You are GAGAN AI, a helpful content assistant. Create original, "
                "useful content in the language requested by the user. Do not claim "
                "that you have published or scheduled anything."
            ),
            input=prompt,
        )
        return {"content": response.output_text}
    except Exception:
        logger.exception("AI generation failed")
        raise HTTPException(
            status_code=502,
            detail="AI service request failed. Check server configuration and try again.",
        )
