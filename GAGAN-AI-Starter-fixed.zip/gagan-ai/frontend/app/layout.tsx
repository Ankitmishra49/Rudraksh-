import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "GAGAN AI — Your AI Workspace",
  description: "AI content tools and affiliate workflow in one workspace.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
