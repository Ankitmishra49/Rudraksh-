"use client";

import { useState } from "react";

const tools = [
  { icon: "✦", name: "AI Content", desc: "Draft captions, posts and ideas." },
  { icon: "▶", name: "Video Scripts", desc: "Plan Shorts, Reels and long videos." },
  { icon: "#", name: "Hashtag Helper", desc: "Generate relevant hashtag ideas." },
  { icon: "↗", name: "Affiliate Links", desc: "Organize your affiliate campaigns." },
];

const plans = [
  { name: "Starter", price: "₹99", desc: "For getting started", features: ["Content workspace", "Basic tools", "Personal projects"] },
  { name: "Pro", price: "₹299", desc: "For regular creators", features: ["AI-assisted content", "Campaign workspace", "More projects"], featured: true },
  { name: "Business", price: "₹999", desc: "For growing teams", features: ["Team-ready workspace", "Campaign planning", "Business support"] },
];

export default function Home() {
  const [prompt, setPrompt] = useState("");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  async function generateContent() {
    if (!prompt.trim()) {
      setResult("पहले अपना विषय लिखें।");
      return;
    }
    setLoading(true);
    setResult("");
    try {
      const apiBase = (process.env.NEXT_PUBLIC_API_URL || "http://127.0.0.1:8000").replace(/\/$/, "");
      const response = await fetch(`${apiBase}/api/ai/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail || "Request failed");
      setResult(data.content || "कोई कंटेंट नहीं मिला।");
    } catch (err) {
      setResult(err instanceof Error ? err.message : "सर्वर से कनेक्शन नहीं हो पाया।");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen overflow-hidden">
      <header className="sticky top-0 z-20 border-b border-white/10 bg-[#080b14]/90 backdrop-blur">
        <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 md:px-10">
          <a href="#" className="text-2xl font-black tracking-tight">GAGAN<span className="text-cyan-300"> AI</span></a>
          <div className="hidden items-center gap-7 text-sm text-slate-300 md:flex">
            <a href="#tools" className="hover:text-cyan-300">Tools</a>
            <a href="#pricing" className="hover:text-cyan-300">Pricing</a>
            <a href="#generate" className="hover:text-cyan-300">AI Workspace</a>
          </div>
          <a href="#generate" className="rounded-xl bg-cyan-300 px-4 py-2.5 text-sm font-bold text-slate-950 hover:bg-cyan-200">Get started</a>
        </nav>
      </header>

      <section className="relative mx-auto max-w-7xl px-5 pb-20 pt-20 md:px-10 md:pb-28 md:pt-28">
        <div className="pointer-events-none absolute left-1/2 top-8 -z-10 h-80 w-80 -translate-x-1/2 rounded-full bg-cyan-500/10 blur-3xl" />
        <div className="mx-auto max-w-4xl text-center">
          <span className="inline-flex rounded-full border border-cyan-300/25 bg-cyan-300/5 px-4 py-2 text-xs font-semibold tracking-[0.2em] text-cyan-200">YOUR ALL-IN-ONE AI WORKSPACE</span>
          <h1 className="mt-7 text-5xl font-black leading-[1.06] tracking-tight sm:text-6xl md:text-8xl">Create faster.<br/><span className="text-cyan-300">Grow smarter.</span></h1>
          <p className="mx-auto mt-7 max-w-2xl text-base leading-7 text-slate-400 md:text-lg">AI-assisted content, video planning and affiliate campaign organization in one clean workspace.</p>
        </div>

        <div id="generate" className="mx-auto mt-12 max-w-3xl rounded-3xl border border-white/10 bg-white/[0.04] p-3 shadow-2xl shadow-cyan-950/20">
          <label htmlFor="prompt" className="sr-only">What do you want to create?</label>
          <textarea id="prompt" value={prompt} onChange={(e) => setPrompt(e.target.value)} maxLength={4000} placeholder="अपना विषय लिखें… जैसे बच्चों के वीडियो के लिए YouTube title और description" className="min-h-32 w-full resize-y bg-transparent p-5 text-base leading-7 outline-none placeholder:text-slate-500" />
          <div className="flex flex-col gap-3 border-t border-white/10 p-2 pt-4 sm:flex-row sm:items-center sm:justify-between">
            <span className="px-3 text-xs text-slate-500">AI API configuration required</span>
            <button onClick={generateContent} disabled={loading} className="rounded-2xl bg-cyan-300 px-6 py-3.5 font-bold text-slate-950 transition hover:bg-cyan-200 disabled:cursor-not-allowed disabled:opacity-50">{loading ? "Generating…" : "✦ Generate with AI"}</button>
          </div>
          {result && <div aria-live="polite" className="m-2 whitespace-pre-wrap rounded-2xl border border-white/10 bg-black/20 p-5 text-sm leading-7 text-slate-200">{result}</div>}
        </div>
        <div className="mt-8 flex flex-wrap justify-center gap-3 text-xs text-slate-500"><span className="rounded-full border border-white/10 px-3 py-2">✦ Creator tools</span><span className="rounded-full border border-white/10 px-3 py-2">↗ Campaign planning</span><span className="rounded-full border border-white/10 px-3 py-2">◈ One workspace</span></div>
      </section>

      <section id="tools" className="mx-auto max-w-7xl px-5 py-16 md:px-10 md:py-20">
        <div className="mb-9 flex flex-col justify-between gap-3 sm:flex-row sm:items-end"><div><p className="text-sm font-semibold uppercase tracking-[0.18em] text-cyan-300">Workspace</p><h2 className="mt-3 text-3xl font-bold md:text-4xl">Tools built for momentum</h2></div><p className="max-w-md text-sm leading-6 text-slate-400">A starter interface for your future AI and marketing workflows.</p></div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{tools.map((tool) => <article key={tool.name} className="rounded-3xl border border-white/10 bg-white/[0.035] p-6 transition hover:-translate-y-1 hover:border-cyan-300/40"><div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-cyan-300/10 text-2xl text-cyan-200">{tool.icon}</div><h3 className="mt-5 text-lg font-bold">{tool.name}</h3><p className="mt-2 text-sm leading-6 text-slate-400">{tool.desc}</p><span className="mt-5 inline-block text-xs font-semibold text-cyan-200">Explore tool ↗</span></article>)}</div>
      </section>

      <section id="pricing" className="mx-auto max-w-7xl px-5 py-16 md:px-10 md:py-20">
        <div className="mx-auto mb-10 max-w-2xl text-center"><p className="text-sm font-semibold uppercase tracking-[0.18em] text-cyan-300">Pricing concept</p><h2 className="mt-3 text-3xl font-bold md:text-4xl">Start free. Scale when ready.</h2><p className="mt-4 text-sm leading-6 text-slate-400">Sample pricing only. Payment checkout is not connected in this starter project.</p></div>
        <div className="grid gap-4 md:grid-cols-3">{plans.map((plan) => <article key={plan.name} className={`rounded-3xl border p-7 ${plan.featured ? "border-cyan-300/60 bg-cyan-300/[0.06]" : "border-white/10 bg-white/[0.025]"}`}><h3 className="text-xl font-bold">{plan.name}</h3><p className="mt-2 text-sm text-slate-400">{plan.desc}</p><p className="mt-7 text-4xl font-black">{plan.price}<span className="text-sm font-normal text-slate-500"> / month</span></p><ul className="mt-6 space-y-3 text-sm text-slate-300">{plan.features.map((feature) => <li key={feature}>✓ &nbsp;{feature}</li>)}</ul><button onClick={() => alert("Subscription checkout is not connected yet.")} className={`mt-8 w-full rounded-xl px-4 py-3 font-bold ${plan.featured ? "bg-cyan-300 text-slate-950" : "border border-white/15 hover:bg-white/5"}`}>Choose {plan.name}</button></article>)}</div>
      </section>

      <footer className="border-t border-white/10 px-5 py-8 text-center text-xs text-slate-500">© {new Date().getFullYear()} GAGAN AI · Starter project · Features require configuration before production use.</footer>
    </main>
  );
}
