@echo off
python -m pip install -r requirements.txt
if not exist .env copy .env.example .env
python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000
