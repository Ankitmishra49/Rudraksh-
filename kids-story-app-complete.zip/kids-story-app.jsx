import React, { useState, useEffect } from 'react';

export default function KidsStoryApp() {
  const [user, setUser] = useState(null);
  const [screen, setScreen] = useState('landing');
  const [language, setLanguage] = useState('hi');
  const [subscription, setSubscription] = useState('free');
  const [stories, setStories] = useState([]);
  const [loading, setLoading] = useState(false);

  const content = {
    hi: {
      appName: '✨ कहानियों का जादू',
      tagline: 'बच्चों के लिए AI से बनी अनोखी कहानियां',
      login: 'लॉगिन करें',
      signup: 'साइन अप करें',
      welcome: 'स्वागत है',
      logout: 'लॉगआउट',
      createStory: 'कहानी बनाएं',
      myStories: 'मेरी कहानियां',
      profile: 'प्रोफाइल',
      character: '🧚 कैरेक्टर चुनें',
      setting: '🏰 जगह चुनें',
      action: '⚡ क्या होगा',
      generate: '🌟 कहानी बनाएं',
      characters: ['बहादुर शूरवीर', 'युवा जादूगर', 'जिज्ञासु खोजी', 'चालाक लोमड़ी', 'मित्रवत रोबोट', 'जादुई राजकुमारी'],
      settings: ['जादुई जंगल', 'पानी का राज्य', 'आकाश का महल', 'रहस्य की गुफा', 'अंतरिक्ष स्टेशन', 'मंत्रमुग्ध गाँव'],
      actions: ['खजाना ढूंढता है', 'नया दोस्त बनाता है', 'रहस्य सुलझाता है', 'रोमांचक यात्रा करता है', 'किसी की मदद करता है', 'जादुई शक्ति पाता है'],
      pricing: 'मूल्य निर्धारण',
      free: 'निःशुल्क',
      premium: 'प्रीमियम',
      pro: 'प्रो',
      storiesPerMonth: 'कहानियां/महीना',
      download: 'डाउनलोड करें',
      printBook: 'किताब प्रिंट करें',
      customStories: 'कस्टम कहानियां',
      subscribe: 'सदस्यता लें',
    },
    en: {
      appName: '✨ Tales of Magic',
      tagline: 'Unique AI-Generated Stories for Kids',
      login: 'Login',
      signup: 'Sign Up',
      welcome: 'Welcome',
      logout: 'Logout',
      createStory: 'Create Story',
      myStories: 'My Stories',
      profile: 'Profile',
      character: '🧚 Pick Character',
      setting: '🏰 Pick Setting',
      action: '⚡ What Happens',
      generate: '🌟 Create Story',
      characters: ['Brave Knight', 'Young Wizard', 'Curious Explorer', 'Clever Fox', 'Friendly Robot', 'Magical Princess'],
      settings: ['Magical Forest', 'Underwater Kingdom', 'Sky Castle', 'Mystery Cave', 'Space Station', 'Enchanted Village'],
      actions: ['Finds Hidden Treasure', 'Makes New Friend', 'Solves Mystery', 'Goes on Adventure', 'Helps Someone', 'Discovers Magic'],
      pricing: 'Pricing',
      free: 'Free',
      premium: 'Premium',
      pro: 'Pro',
      storiesPerMonth: 'Stories/Month',
      download: 'Download',
      printBook: 'Print Book',
      customStories: 'Custom Stories',
      subscribe: 'Subscribe',
    }
  };

  const t = content[language];

  const generateStory = async (char, set, act) => {
    setLoading(true);
    const prompt = `Write a fun, magical story for kids (ages 5-8) about:\n- Character: ${char}\n- Setting: ${set}\n- Action: ${act}\n\nMake it 3 paragraphs. Use simple, engaging words. Add magical elements!`;

    try {
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-6',
          max_tokens: 600,
          messages: [{ role: 'user', content: prompt }]
        })
      });

      const data = await response.json();
      const story = {
        id: Date.now(),
        title: `${char} in ${set}`,
        content: data.content[0].text,
        character: char,
        setting: set,
        date: new Date().toLocaleDateString(language === 'hi' ? 'hi-IN' : 'en-US')
      };
      
      setStories([story, ...stories]);
      return story;
    } catch (error) {
      console.error('Error:', error);
      return null;
    } finally {
      setLoading(false);
    }
  };

  // Landing Screen
  if (screen === 'landing') {
    return (
      <div style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
        <div style={{ padding: '1rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h1 style={{ fontSize: '24px', color: 'white', margin: 0, fontWeight: 600 }}>{t.appName}</h1>
          <select value={language} onChange={(e) => setLanguage(e.target.value)} style={{ padding: '8px 12px', borderRadius: '6px', border: 'none', background: 'white', cursor: 'pointer' }}>
            <option value="hi">हिंदी</option>
            <option value="en">English</option>
          </select>
        </div>

        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '2rem', textAlign: 'center' }}>
          <div style={{ fontSize: '80px', marginBottom: '1rem' }}>✨📖🎭</div>
          <h2 style={{ fontSize: '32px', color: 'white', marginBottom: '0.5rem', fontWeight: 600 }}>{t.tagline}</h2>
          <p style={{ fontSize: '16px', color: 'rgba(255,255,255,0.9)', marginBottom: '2rem' }}>
            {language === 'hi' ? 'हर बार एक नई जादुई कहानी' : 'A magical new story every time'}
          </p>
          
          <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', justifyContent: 'center' }}>
            <button onClick={() => { setUser({ name: 'Guest User' }); setScreen('create'); }} 
              style={{ padding: '12px 28px', background: 'white', color: '#667eea', border: 'none', borderRadius: '8px', fontSize: '16px', fontWeight: 600, cursor: 'pointer' }}>
              {t.createStory} 🚀
            </button>
            <button onClick={() => setScreen('pricing')} 
              style={{ padding: '12px 28px', background: 'rgba(255,255,255,0.2)', color: 'white', border: '2px solid white', borderRadius: '8px', fontSize: '16px', fontWeight: 600, cursor: 'pointer' }}>
              {t.pricing} 💰
            </button>
          </div>
        </div>

        <div style={{ padding: '2rem', background: 'rgba(0,0,0,0.2)', borderRadius: '16px 16px 0 0', margin: '2rem 1rem 0', color: 'white' }}>
          <h3 style={{ marginTop: 0 }}>✨ {language === 'hi' ? 'विशेषताएं' : 'Features'}</h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '12px', fontSize: '14px' }}>
            <div>🎨 {language === 'hi' ? 'AI से कहानियां' : 'AI-Powered Stories'}</div>
            <div>🌍 {language === 'hi' ? 'दोनों भाषाएं' : 'Bilingual Support'}</div>
            <div>📱 {language === 'hi' ? 'सभी डिवाइस' : 'All Devices'}</div>
            <div>👨‍👩‍👧 {language === 'hi' ? 'अभिभावक नियंत्रण' : 'Parental Controls'}</div>
            <div>📚 {language === 'hi' ? 'किताब प्रिंट करें' : 'Print as Book'}</div>
            <div>🎁 {language === 'hi' ? 'असीमित कहानियां' : 'Unlimited Stories'}</div>
          </div>
        </div>
      </div>
    );
  }

  // Pricing Screen
  if (screen === 'pricing') {
    const plans = [
      { name: t.free, price: '0', features: ['5 कहानियां/महीना', 'HD डाउनलोड', 'English & Hindi', 'Ad-supported'] },
      { name: t.premium, price: '99', features: ['असीमित कहानियां', 'PDF डाउनलोड', 'Ad-free', 'Offline mode', 'Parent dashboard'], highlight: true },
      { name: t.pro, price: '299', features: ['All Premium', 'Custom stories', 'Print books', 'Analytics', 'No watermark', 'Priority support'] }
    ];

    return (
      <div style={{ padding: '2rem', background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)', minHeight: '100vh' }}>
        <button onClick={() => setScreen('landing')} style={{ marginBottom: '1rem', padding: '8px 16px', background: '#667eea', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer' }}>← {language === 'hi' ? 'वापस' : 'Back'}</button>
        
        <h2 style={{ textAlign: 'center', fontSize: '28px', color: '#333', marginBottom: '3rem' }}>{t.pricing} 💰</h2>
        
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '20px', maxWidth: '1200px', margin: '0 auto' }}>
          {plans.map((plan, i) => (
            <div key={i} style={{ 
              background: 'white', 
              padding: '2rem', 
              borderRadius: '12px', 
              boxShadow: plan.highlight ? '0 8px 24px rgba(102, 126, 234, 0.4)' : '0 2px 8px rgba(0,0,0,0.1)',
              border: plan.highlight ? '3px solid #667eea' : 'none',
              transform: plan.highlight ? 'scale(1.05)' : 'scale(1)',
              transition: 'all 0.3s'
            }}>
              {plan.highlight && <div style={{ background: '#667eea', color: 'white', padding: '4px 12px', borderRadius: '4px', fontSize: '12px', fontWeight: 600, marginBottom: '1rem', width: 'fit-content' }}>⭐ {language === 'hi' ? 'सबसे लोकप्रिय' : 'MOST POPULAR'}</div>}
              <h3 style={{ fontSize: '20px', marginBottom: '0.5rem' }}>{plan.name}</h3>
              <div style={{ fontSize: '28px', fontWeight: 'bold', color: '#667eea', marginBottom: '1rem' }}>₹{plan.price}<span style={{ fontSize: '14px', color: '#999', marginLeft: '4px' }}>/{language === 'hi' ? 'माह' : 'mo'}</span></div>
              <ul style={{ listStyle: 'none', padding: 0, marginBottom: '1.5rem' }}>
                {plan.features.map((f, j) => (
                  <li key={j} style={{ padding: '8px 0', fontSize: '14px', color: '#666', borderBottom: '1px solid #eee' }}>✓ {f}</li>
                ))}
              </ul>
              <button style={{ width: '100%', padding: '10px', background: plan.highlight ? '#667eea' : '#f0f0f0', color: plan.highlight ? 'white' : '#333', border: 'none', borderRadius: '6px', fontWeight: 600, cursor: 'pointer' }}>
                {t.subscribe}
              </button>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Story Creator Screen
  if (screen === 'create') {
    const [char, setChar] = useState(t.characters[0]);
    const [sett, setSett] = useState(t.settings[0]);
    const [act, setAct] = useState(t.actions[0]);
    const [story, setStory] = useState(null);

    return (
      <div style={{ padding: '1rem', background: 'linear-gradient(135deg, #E8F4F8 0%, #F0E8F8 100%)', minHeight: '100vh' }}>
        <div style={{ maxWidth: '600px', margin: '0 auto' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
            <h1 style={{ fontSize: '24px', color: '#7F77DD', margin: 0, fontWeight: 600 }}>✨ {t.appName}</h1>
            <button onClick={() => setScreen('landing')} style={{ padding: '8px 16px', background: '#666', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer' }}>{language === 'hi' ? 'होम' : 'Home'}</button>
          </div>

          {!story ? (
            <div style={{ background: 'white', borderRadius: '12px', padding: '1.5rem', boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
              <div style={{ marginBottom: '1.5rem' }}>
                <label style={{ display: 'block', fontWeight: 500, marginBottom: '0.5rem', fontSize: '15px' }}>{t.character}</label>
                <select value={char} onChange={(e) => setChar(e.target.value)} style={{ width: '100%', padding: '10px', border: '2px solid #85B7EB', borderRadius: '8px', fontSize: '14px' }}>
                  {t.characters.map((c, i) => <option key={i}>{c}</option>)}
                </select>
              </div>

              <div style={{ marginBottom: '1.5rem' }}>
                <label style={{ display: 'block', fontWeight: 500, marginBottom: '0.5rem', fontSize: '15px' }}>{t.setting}</label>
                <select value={sett} onChange={(e) => setSett(e.target.value)} style={{ width: '100%', padding: '10px', border: '2px solid #5DCAA5', borderRadius: '8px', fontSize: '14px' }}>
                  {t.settings.map((s, i) => <option key={i}>{s}</option>)}
                </select>
              </div>

              <div style={{ marginBottom: '2rem' }}>
                <label style={{ display: 'block', fontWeight: 500, marginBottom: '0.5rem', fontSize: '15px' }}>{t.action}</label>
                <select value={act} onChange={(e) => setAct(e.target.value)} style={{ width: '100%', padding: '10px', border: '2px solid #EF9F27', borderRadius: '8px', fontSize: '14px' }}>
                  {t.actions.map((a, i) => <option key={i}>{a}</option>)}
                </select>
              </div>

              <button 
                onClick={() => generateStory(char, sett, act).then(s => s && setStory(s))} 
                disabled={loading}
                style={{ width: '100%', padding: '12px', background: loading ? '#ccc' : 'linear-gradient(135deg, #534AB7 0%, #7F77DD 100%)', color: 'white', border: 'none', borderRadius: '8px', fontSize: '16px', fontWeight: 600, cursor: loading ? 'not-allowed' : 'pointer' }}>
                {loading ? '⏳ ' + (language === 'hi' ? 'बना रहे हैं...' : 'Creating...') : t.generate}
              </button>
            </div>
          ) : (
            <div style={{ background: 'white', borderRadius: '12px', padding: '2rem', boxShadow: '0 2px 8px rgba(0,0,0,0.1)', borderLeft: '5px solid #7F77DD' }}>
              <h2 style={{ fontSize: '20px', fontWeight: 600, color: '#534AB7', marginTop: 0 }}>📖 {story.title}</h2>
              <p style={{ fontSize: '14px', color: '#999', marginBottom: '1rem' }}>{language === 'hi' ? 'तारीख' : 'Date'}: {story.date}</p>
              <div style={{ fontSize: '16px', lineHeight: '1.8', color: '#333', fontFamily: 'Georgia, serif', whiteSpace: 'pre-wrap', marginBottom: '1.5rem', maxHeight: '400px', overflow: 'auto', paddingRight: '1rem' }}>
                {story.content}
              </div>
              <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
                <button onClick={() => setStory(null)} style={{ flex: 1, padding: '10px', background: '#5DCAA5', color: 'white', border: 'none', borderRadius: '6px', fontWeight: 600, cursor: 'pointer' }}>📝 {language === 'hi' ? 'दूसरी कहानी' : 'Another Story'}</button>
                <button style={{ flex: 1, padding: '10px', background: '#EF9F27', color: 'white', border: 'none', borderRadius: '6px', fontWeight: 600, cursor: 'pointer' }}>💾 {t.download}</button>
                <button style={{ flex: 1, padding: '10px', background: '#667eea', color: 'white', border: 'none', borderRadius: '6px', fontWeight: 600, cursor: 'pointer' }}>📚 {t.printBook}</button>
              </div>
            </div>
          )}

          {stories.length > 0 && (
            <div style={{ marginTop: '2rem' }}>
              <h3 style={{ fontSize: '18px', fontWeight: 600, color: '#333' }}>📚 {language === 'hi' ? 'पिछली कहानियां' : 'Previous Stories'}</h3>
              <div style={{ display: 'grid', gap: '12px' }}>
                {stories.slice(0, 3).map((s) => (
                  <div key={s.id} style={{ background: 'white', padding: '1rem', borderRadius: '8px', cursor: 'pointer', border: '1px solid #eee' }} onClick={() => setStory(s)}>
                    <div style={{ fontWeight: 600, color: '#333' }}>{s.title}</div>
                    <div style={{ fontSize: '13px', color: '#999' }}>{s.date}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  return null;
}
